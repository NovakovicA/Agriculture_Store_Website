
var express = require("express");
var router = express.Router();

var Rasadnik = require("./models/rasadnik");
var Sadnica = require("./models/sadnica");
var Preparat = require("./models/preparat");
var Preduzece = require("./models/preduzece");
var Narudzbina = require("./models/narudzbina");
var Komentar = require("./models/komentar");

router.post("/addsadnica/",async function(req,res){
  try{
      var counta = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali preduzeca.");
      }
      else{
      var countb = await Sadnica.find({naziv:req.body.naziv,pred:req.body.korime,narudzbina:null}).countDocuments();
      if(countb!=0){
        res.json("Vec postoji sadnica sa istim imenom.");
      }
  else{
    var sad = new Sadnica ({
      naziv:req.body.naziv,
      pred:req.body.korime,
      cena:req.body.cena,
      kolicina:req.body.kolicina,
      poljoprivrednik:null,
      rasadnik:null,
      pozicija:0,
      trenrast:0,
      maxrast:req.body.maxrast,
      narudzbina:null
    });
    await sad.save();
    res.json("Uspesno dodata nova sadnica.");
    }}}
    catch(err){
      res.json(err.message);
    }
 });

 router.post("/removesadnica/",async function(req,res){
  try{
      var counta = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali preduzeca.");
      }
      else{
      var countb = await Sadnica.find({naziv:req.body.naziv,pred:req.body.korime,narudzbina:null}).countDocuments();
      if(countb==0){
        res.json("Ne postoji sadnica.");
      }
      else{
        await Sadnica.deleteOne({naziv:req.body.naziv,pred:req.body.korime,narudzbina:null});
        res.json("Uspesno obrisana sadnica.");
      }
    }
  }
    catch(err){
      res.json(err.message);
    }
 });

 router.post("/modifysadnica/",async function(req,res){
  try{
      var counta = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali preduzeca.");
      }
      else{
      var countb = await Sadnica.find({naziv:req.body.naziv,pred:req.body.korime,narudzbina:null}).countDocuments();
      if(countb==0){
        res.json("Ne postoji sadnica.");
      }
      else{
        await Sadnica.updateOne({naziv:req.body.naziv,pred:req.body.korime,narudzbina:null},{kolicina:req.body.kolicina,cena:req.body.cena});
        res.json("Uspesno modifikovana sadnica.");
      }
    }
  }
    catch(err){
      res.json(err.message);
    }
 });




 router.post("/addpreparat/",async function(req,res){
  try{
      var counta = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali preduzeca.");
      }
      else{
      var countb = await Preparat.find({naziv:req.body.naziv,pred:req.body.korime,narudzbina:null}).countDocuments();
      if(countb!=0){
        res.json("Vec postoji preparat sa istim imenom.");
      }
  else{
    var prep = new Preparat ({
      naziv:req.body.naziv,
      pred:req.body.korime,
      cena:req.body.cena,
      kolicina:req.body.kolicina,
      poljoprivrednik:null,
      rasadnik:null,
      ubrzavanje:req.body.ubrzavanje,
      narudzbina:null
    });
    await prep.save();
    res.json("Uspesno dodat nov preparat.");
    }}}
    catch(err){
      res.json(err.message);
    }
 });

 router.post("/removepreparat/",async function(req,res){
  try{
      var counta = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali preduzeca.");
      }
      else{
      var countb = await Preparat.find({naziv:req.body.naziv,pred:req.body.korime}).countDocuments();
      if(countb==0){
        res.json("Ne postoji preparat.");
      }
      else{
        await Preparat.deleteOne({naziv:req.body.naziv,pred:req.body.korime});
        res.json("Uspesno obrisan preparat.");
      }
    }
  }
    catch(err){
      res.json(err.message);
    }
 });

 router.post("/modifypreparat/",async function(req,res){
  try{
      var counta = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali preduzeca.");
      }
      else{
      var countb = await Preparat.find({naziv:req.body.naziv,pred:req.body.korime}).countDocuments();
      if(countb==0){
        res.json("Ne postoji preparat.");
      }
      else{
        await Preparat.updateOne({naziv:req.body.naziv,pred:req.body.korime},{kolicina:req.body.kolicina,cena:req.body.cena});
        res.json("Uspesno modifikovan preparat.");
      }
    }
  }
    catch(err){
      res.json(err.message);
    }
 });


 router.post("/getsadnice",async (req,res)=>{
  try{
    var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali preduzeca.");
    }
    else{
var sadnice = await Sadnica.find({pred:req.body.korime,narudzbina:null}).select("-__v").select("-_id").select("-poljoprivrednik").select("-rasadnik")
.select("-narudzbina");
res.json(sadnice);
}}
catch(err){
  res.json( "Doslo je do greske." );
}
});

router.post("/getpreparati",async (req,res)=>{
  try{
    var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali preduzeca.");
    }
    else{
var prep = await Preparat.find({pred:req.body.korime,narudzbina:null}).select("-__v").select("-_id").select("-poljoprivrednik").select("-rasadnik")
.select("-narudzbina");
res.json(prep);
}}
catch(err){
  res.json( "Doslo je do greske." );
}
});

router.post("/getnarudzbine",async (req,res)=>{
  try{
    var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali preduzeca.");
    }
    else{
var narudzbine  = await Narudzbina.find({pred:req.body.korime,$or:[{status:"Na odobravanju"},{status:"Na cekanju"},{status:"U transportu"}]}).select("-__v").select("-_id");
res.json(narudzbine);
}}
catch(err){
  res.json( "Doslo je do greske." );
}
});

router.post("/getnar_sadnice",async (req,res)=>{
  try{
    var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali preduzeca.");
    }
    else{
      var sadnice = await Sadnica.find({pred:req.body.korime,narudzbina:req.body.narudzbinaid}).select("-__v").select("-_id");
res.json(sadnice);
}}
catch(err){
  res.json( "Doslo je do greske." );
}
});

router.post("/getnar_preparati",async (req,res)=>{
  try{
    var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali preduzeca.");
    }
    else{
var prep = await Preparat.find({pred:req.body.korime,narudzbina:req.body.narudzbinaid}).select("-__v").select("-_id");
res.json(prep);
}}
catch(err){
  res.json("Doslo je do greske");
}
});


router.post("/removenarudzbina",async (req,res)=>{
  try{
    var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali preduzeca.");
    }
    else{
      count = await Narudzbina.find({id:req.body.narudzbinaid,status:"Na odobravanju"}).countDocuments();
      if(count==0){
        res.json("Narudzbina ne postoji.");
      }
      else{
        var preps=await Preparat.find({narudzbina:req.body.narudzbinaid});
        var sads=await Sadnica.find({narudzbina:req.body.narudzbinaid});

        preps.forEach( async (val) => {
          var count2=await Preparat.find({naziv:val.naziv,pred:val.pred,narudzbina:null}).countDocuments();
          var prep2=(await Preparat.find({naziv:val.naziv,pred:val.pred,narudzbina:null}))[0];
          if (count2==0){
           await  Preparat.updateOne({naziv:val.naziv,pred:val.pred},{narudzbina:null});
          }
          else{
            var novakol=prep2.kolicina+val.kolicina;
            await  Preparat.updateOne({naziv:val.naziv,pred:val.pred,narudzbina:null},{kolicina:novakol});
            await  Preparat.deleteOne(val);
          }
        });

        sads.forEach( async (val) => {
          var count2=await Sadnica.find({naziv:val.naziv,pred:val.pred,narudzbina:null}).countDocuments();
          var sads2=(await Sadnica.find({naziv:val.naziv,pred:val.pred,narudzbina:null}))[0];
          if (count2==0){
           await  Sadnica.updateOne({naziv:val.naziv,pred:val.pred,kolicina:val.kolicina},{narudzbina:null});
          }
          else{
            var novakol=sads2.kolicina+val.kolicina;
            await Sadnica.updateOne({naziv:val.naziv,pred:val.pred,narudzbina:null},{kolicina:novakol});
            await Sadnica.deleteOne(val);
          }
        });


         await Narudzbina.deleteOne({id:req.body.narudzbinaid});
         res.json("Uspesno obrisana narudzbina.");

      }
    }
  }
  catch(err){
    res.json( err.message );
  }
  });

  router.post("/confirmnarudzbina",async (req,res)=>{
    try{
      var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali preduzeca.");
      }
      else{
        var nar = await Narudzbina.find({id:req.body.narudzbinaid,status:"Na odobravanju"});
        count = nar.length;
        if(count==0){
          res.json("Narudzbina ne postoji.");
        }
        else{
          await Narudzbina.updateOne({id:req.body.narudzbinaid},{status:"Na cekanju"});
          res.json("Uspesno potvrdjena narudzbina.");
        }
      }
    }
    catch(err){
      res.json( err.message );
    }
    });

    router.post("/getsvenarudzbine",async (req,res)=>{
      try{
        var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        if(count==0){
          res.json("Pogresni kredencijali preduzeca.");
        }
        else{
    var narudzbine  = await Narudzbina.find({pred:req.body.korime,$or:[{status:"Na odobravanju"},{status:"Na cekanju"},{status:"U transportu"},{status:"Isporucena"}]}).select("-__v").select("-_id");
    res.json(narudzbine);
    }}
    catch(err){
      res.json( "Doslo je do greske." );
    }
    });

    router.post("/getkomentarisad",async (req,res)=>{
      try{
        var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        if(count==0){
          res.json("Pogresni kredencijali preduzeca.");
        }
    else{
        var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.korime,tip:"S"});
        res.json(komentari);
    }}
    catch(err){
      res.json("Doslo je do greske");
    }
    });

    router.post("/getkomentariprep",async (req,res)=>{
      try{
        var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        if(count==0){
          res.json("Pogresni kredencijali preduzeca.");
        }
    else{
        var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.korime,tip:"P"});
        res.json(komentari);
    }}
    catch(err){
      res.json("Doslo je do greske");
    }
    });


    router.post("/getocenasad",async (req,res)=>{
      try{
        var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        if(count==0){
          res.json(-1);
        }
   else{
        var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,tip:"S"});
        if(komentari.length==0){
          res.json(0);
        }
        else{
          let ocena=0; let ukupanbrojocena=komentari.length;
          komentari.forEach((el)=>{
            ocena+=el.ocena;
          });
          res.json(Math.round(ocena/ukupanbrojocena));
        }
   }}
    catch(err){
      res.json(-1);
    }
    });

    router.post("/getocenaprep",async (req,res)=>{
      try{
        var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        if(count==0){
          res.json(-1);
        }
   else{
        var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,tip:"P"});
        if(komentari.length==0){
          res.json(0);
        }
        else{
          let ocena=0; let ukupanbrojocena=komentari.length;
          komentari.forEach((el)=>{
            ocena+=el.ocena;
          });
          res.json(Math.round(ocena/ukupanbrojocena));
        }
   }}
    catch(err){
      res.json(-1);
    }
    });



module.exports = router;
