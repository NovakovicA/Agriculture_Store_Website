const mongoose = require("mongoose");

var zahtevPreduzeca = mongoose.model("zahtevPreduzeca",{
naziv:{type:String},
korime:{type:String},
lozinka:{type:String},
datum:{type:Date},
mesto:{type:String},
email:{type:String}
},"zahtevi_preduzeca");


module.exports =zahtevPreduzeca;
