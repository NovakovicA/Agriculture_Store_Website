const mongoose = require("mongoose");

var zahtevPoljoprivrednika = mongoose.model("zahtevPoljoprivrednika",{
ime:{type:String},
prezime:{type:String},
korime:{type:String},
lozinka:{type:String},
datum:{type:Date},
mesto:{type:String},
email:{type:String},
telefon:{type:String}
},"zahtevi_poljoprivrednici");

module.exports=zahtevPoljoprivrednika;
