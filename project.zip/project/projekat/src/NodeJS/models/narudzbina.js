const mongoose = require("mongoose");
var Schema = mongoose.Schema;

var Narudzbina = mongoose.model("Narudzbina",new Schema({
id:Number,
poljoprivrednik:String,
rasadnik:String,
pred:String,
status:String,
datum:Date
}),"narudzbine");

module.exports = Narudzbina;
