const mongoose = require("mongoose");

var Preduzece = mongoose.model("Preduzece",{
naziv:{type:String},
korime:{type:String},
lozinka:{type:String},
datum:{type:Date},
mesto:{type:String},
email:{type:String}
},"preduzeca");

module.exports = Preduzece;
