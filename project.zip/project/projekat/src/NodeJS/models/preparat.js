const mongoose = require("mongoose");
var Schema = mongoose.Schema;

var Preparat = mongoose.model("Preparat",new Schema({
naziv:String,
pred:String,
cena:Number,
kolicina:Number,
poljoprivrednik:String,
rasadnik:String,
ubrzavanje:Number,
narudzbina:Number
}),"preparati");

module.exports = Preparat;
