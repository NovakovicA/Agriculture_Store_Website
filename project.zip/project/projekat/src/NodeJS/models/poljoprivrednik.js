const mongoose = require("mongoose");

var Poljoprivrednik = mongoose.model("Poljoprivrednik",{
ime:{type:String},
prezime:{type:String},
korime:{type:String},
lozinka:{type:String},
datum:{type:Date},
mesto:{type:String},
email:{type:String},
telefon:{type:String}
},"poljoprivrednici");

module.exports=Poljoprivrednik;
