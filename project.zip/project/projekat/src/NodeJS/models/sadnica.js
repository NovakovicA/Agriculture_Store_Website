const mongoose = require("mongoose");
var Schema = mongoose.Schema;


var Sadnica = mongoose.model("Sadnica",new Schema({
  naziv:String,
  pred:String,
  cena:Number,
  kolicina:Number,
  poljoprivrednik:String,
  rasadnik:String,
  pozicija:Number,
  trenrast:Number,
  maxrast:Number,
  narudzbina:Number
}),"sadnice");

module.exports = Sadnica;
