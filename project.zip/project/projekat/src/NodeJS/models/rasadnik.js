const mongoose = require("mongoose");

var Rasadnik = mongoose.model("Rasadnik",{
korime:{type:String},
naziv:{type:String},
mesto:{type:String},
brzas:{type:Number},
bruk:{type:Number},
voda:{type:Number},
temp:{type:String}
},"rasadnici");

module.exports = Rasadnik;
