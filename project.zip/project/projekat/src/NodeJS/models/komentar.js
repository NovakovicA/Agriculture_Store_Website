const mongoose = require("mongoose");
var Schema = mongoose.Schema;

var Komentar = mongoose.model("Komentar",new Schema({
naziv:String,
sadrzaj:String,
ocena:Number,
poljoprivrednik:String,
pred:String,
tip:String
}),"komentari");

module.exports = Komentar;
