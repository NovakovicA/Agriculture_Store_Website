const mongoose = require("mongoose");

var Administrator = mongoose.model("Administrator",{
korime:{type:String},
lozinka:{type:String}
},"administratori");

module.exports=Administrator;
