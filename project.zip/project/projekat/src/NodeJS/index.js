const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
const cors = require("cors");

var app = express();
app.use(bodyParser.json());

var api_general=require("./api_general");
var api_poljoprivrednik = require("./api_poljoprivrednik");
var api_preduzece = require("./api_preduzece");



app.use(cors());





mongoose.connect("mongodb://localhost:27017/DB",{useNewUrlParser: true ,useUnifiedTopology: true,},(err)=>{
  if(!err) {
    console.log('Successfully connected to MongoDB.');
  }
  else{
    console.log("Error connecting to MongoDB: " + JSON.stringify(err,undefined,2));
  }
});

app.listen(3000, () => console.log("NodeJS server started on port: 3000"));

app.use("/",api_general);
app.use("/pp",api_poljoprivrednik);
app.use("/p",api_preduzece);

// Podesavanje vremena, slanja mejlova i API
var oneHour=60000;
var sendMail=false;
var distanceAPIkey="5oaH2X8BM783vXhjDZ5I86jZORjfO";
var useDistanceAPI=true;



var Rasadnik=require("./models/rasadnik");
var Preduzece=require("./models/preduzece");
var Narudzbina=require("./models/narudzbina")
var Sadnica=require("./models/sadnica");
var Preparat=require("./models/preparat");
var Poljoprivrednik=require("./models/poljoprivrednik");
const nodemailer = require("nodemailer");

var poslatiMejlovi=[];

const SmanjivanjeTempVodeiRastBiljaka = setInterval(async function(){
var rasadnici = await Rasadnik.find();
rasadnici.forEach(async (val)=>{
  var uvoda=val.voda;
  if(uvoda>=1) uvoda=uvoda-1;
  else uvoda=0;

  if((uvoda<75 || parseFloat(val.temp)-0.5<12) && !poslatiMejlovi.includes(val.korime + " " + val.naziv) && sendMail){
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'PIAna170305d@gmail.com',
    pass: 'mynameispia1337'
  }
});

    var polj = await Poljoprivrednik.find({korime:val.korime});
    var mejl = polj[0].email;
    let info = await transporter.sendMail({
      from: 'Projekat - Notifikacija',
      to: mejl,
      subject: "Projekat - Notifikacija",
      text: "Rasadnik " + val.naziv + " zahteva odrzavanje.",
    });
    poslatiMejlovi.push(val.korime + " " + val.naziv);
    console.log("Email poruka poslata: " +  info.messageId);
  }

  await Rasadnik.updateOne({naziv:val.naziv,korime:val.korime},{voda:uvoda,temp:parseFloat(val.temp)-0.5});
});
var sadnice = await Sadnica.find({narudzbina:0,pozicija:{$ne:0},pozicija:{$ne:null}});
sadnice.forEach(async(val)=>{
if(val.trenrast<val.maxrast && val.pozicija!=0){
  await Sadnica.updateOne(val,{trenrast:val.trenrast+1});
}
});
},oneHour);

const https = require('https');
var preduzeca=null;
var vremeZauzetosti=null;
var prtljag=null;




const primajNarudzbine = setInterval(async function(){
  try{
    //-Dodela pocetnih vrednosti----------------------------
    if(preduzeca==null) { preduzeca = await Preduzece.find({});}

    if(vremeZauzetosti==null){
    vremeZauzetosti=new Array(preduzeca.length);
    for(var i=0;i<preduzeca.length;i++){
      vremeZauzetosti[i]=new Array(5);
     for(var j=0;j<5;j++) vremeZauzetosti[i][j]=0;
    }}

    if(prtljag==null){
      prtljag = new Array(preduzeca.length);
      for(var i=0;i<preduzeca.length;i++){
        prtljag[i]=new Array(5);
        for(var j=0;j<5;j++) prtljag[i][j]=0;
      }
    }
    //------------------------------------------------------
    //-Azuriranje preduzeca---------------------------------
  preduzeca2=await Preduzece.find({});;

    preduzeca2.forEach((el)=>{
      var found=false;
      preduzeca.forEach((el2)=>{if(el.korime==el2.korime) found=true;});
        if(!found){
        len=preduzeca.push(el);
        var p=[0,0,0,0,0];
        vremeZauzetosti.push(p);
        var p2=[0,0,0,0,0];
        prtljag.push(p2);
      }
    });

    preduzeca.forEach((el)=>{
      var found=false;
      preduzeca2.forEach((el2)=>{if(el.korime==el2.korime) found=true;});
      if (!found){
        len=preduzeca.indexOf(el)
        preduzeca.splice(len,1);
        vremeZauzetosti.splice(len,1);
        prtljag.splice(len,1);
      }
    });
    //------------------------------------------------------

    //-Glavni deo(dohvatanje narudzbina/azuriranje)---------
    for(var el of preduzeca){
      var len=preduzeca.indexOf(el);
      for(var i=0;i<5;i++){
        if((vremeZauzetosti[len][i]>0) && (prtljag[len][i]!=0)){
          vremeZauzetosti[len][i]--;
          if(vremeZauzetosti[len][i]==0){
            var narudzbine=await Narudzbina.find({id:prtljag[len][i]});
            var polj = narudzbine[0].poljoprivrednik;
            var ras = narudzbine[0].rasadnik;
            var sadnice=await Sadnica.find({narudzbina:prtljag[len][i]});
            var preparati=await Preparat.find({narudzbina:prtljag[len][i]});
            console.log("[-] Isporucena narudzbina br." + prtljag[len][i] + " poljoprivredniku " + polj + ".");
            console.log("[-] Sadrzaj narudzbine: broj sadnica(" + sadnice.length + ") broj preparata(" + preparati.length + ").")
            for(var s of sadnice){
              await Sadnica.updateOne(s,{poljoprivrednik:polj,rasadnik:ras,narudzbina:0,pozicija:0});
            }
              for(var p of preparati){
              await Preparat.updateOne(p,{poljoprivrednik:polj,rasadnik:ras,narudzbina:0});
            }
            await Narudzbina.updateOne(narudzbine[0],{status:"Isporucena"});
            prtljag[len][i]=0;
          }

        }
      }
    }


    for(var el of preduzeca){
      var narudzbine=await Narudzbina.find({pred:el.korime,status:"Na cekanju"});
      var len=preduzeca.indexOf(el);

      for(var nar of narudzbine) {
        for(var i=0;i<5;i++){
          if((vremeZauzetosti[len][i]==0) && (prtljag[len][i]==0)){
            var pred1=await Preduzece.find({korime:nar.pred});
            var ras1 =await Rasadnik.find({naziv:nar.rasadnik,korime:nar.poljoprivrednik});
           //console.log(pred1[0].mesto + " " + ras1[0].mesto);
            if(useDistanceAPI==true){
           //Distance Matrix API deo
           try{
                var ch =await get_distance(pred1[0].mesto,ras1[0].mesto);
                var obj = JSON.parse(ch);
                prtljag[len][i]=nar.id;
                if(Math.round(obj.rows[0].elements[0].duration.value/3600!=0)){
                vremeZauzetosti[len][i]=Math.round(obj.rows[0].elements[0].duration.value/3600);
                }
                else{
                  prtljag[len][i]=nar.id;
                  vremeZauzetosti[len][i]=10;
                }
                await Narudzbina.updateOne(nar,{status:"U transportu"});
                console.log("[+] Narudzbina br." + prtljag[len][i] + " se nalazi u transportu.");
              }
              catch(ex){
                console.log(ex.message);
                prtljag[len][i]=nar.id;
                vremeZauzetosti[len][i]=10;
                await Narudzbina.updateOne(nar,{status:"U transportu"});
                console.log("[+] Narudzbina br." + prtljag[len][i] + " se nalazi u transportu.");
              }
            }

            else{
              prtljag[len][i]=nar.id;
              vremeZauzetosti[len][i]=10;
              await Narudzbina.updateOne(nar,{status:"U transportu"});
              console.log("[+] Narudzbina br." + prtljag[len][i] + " se nalazi u transportu.");
            }
            break;
          }
        }}
    }

    for(var i=0;i<preduzeca.length;i++){
      console.log("[*] Preduzece " + preduzeca[i].korime + " " + vremeZauzetosti[i] + " " + prtljag[i]);
    }
    console.log("");
    //------------------------------------------------------
  }
  catch(err){
    console.log(err);
  }
},5000);

async function get_distance(mesto1,mesto2){
  return new Promise((resolve,reject)=>{
  try{
  https.get("https://api.distancematrix.ai/maps/api/distancematrix/json?origins=" + mesto1 + "&destinations=" +mesto2+
  "&key=" + distanceAPIkey,function (res){res.setEncoding('utf8'); res.on("data",(ch)=>{resolve(ch)});});
}
catch(ex){
  reject(ex);
}
});
}



