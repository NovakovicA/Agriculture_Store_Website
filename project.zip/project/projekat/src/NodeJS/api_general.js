var mongoose = require("mongoose");
var express = require("express");
var router = express.Router();

var Administrator = require("./models/administrator");
var Poljoprivrednik = require("./models/poljoprivrednik");
var Preduzece = require("./models/preduzece");
var zahtevPreduzeca = require("./models/zahtevpreduzeca");
var zahtevPoljoprivrednika=require("./models/zahtevpoljoprivrednika");
var Rasadnik = require("./models/rasadnik");
var Sadnica = require("./models/sadnica");
var Preparat = require("./models/preparat");


router.post("/addadmin/",async function(req,res){
try{
  var admin = new Administrator({
    korime:req.body.korime,
    lozinka:req.body.lozinka
    });

    var counta = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(counta==0){
      res.json("Pogresni kredencijali administratora.");
    }
else{
var count = await Administrator.find({korime:req.body.korime}).countDocuments();
  if(count!=0){
    res.json("Korisnicko ime je vec registrovano.");
  }

if(count==0){
  var count = await Poljoprivrednik.find({korime:req.body.korime}).countDocuments();
  if(count!=0){
    res.json("Korisnicko ime je vec registrovano.");
  }
}

if(count==0){
  var count = await Preduzece.find({korime:req.body.korime}).countDocuments();
  if(count!=0){
    res.json("Korisnicko ime je vec registrovano.");
  }
}

if(count==0){
  admin.save();
  res.json("Uspesno napravljen administratorski nalog.");
}
}}
catch(err){
  res.json( err.message )
}
});

router.post("/addpoljoprivrednik/",async function(req,res){
  try{
    var polj = new Poljoprivrednik({
      ime:req.body.ime,
      prezime:req.body.prezime,
      korime:req.body.korime,
      lozinka:req.body.lozinka,
      datum:req.body.datum,
      mesto:req.body.mesto,
      email:req.body.email,
      telefon:req.body.telefon
      });
      var counta = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali administratora.");
      }
else{
  var count = await Administrator.find({korime:req.body.korime}).countDocuments();
    if(count!=0){
      res.json("Korisnicko ime je vec registrovano.");
    }

  if(count==0){
    var count = await Poljoprivrednik.find({korime:req.body.korime}).countDocuments();
    if(count!=0){
      res.json("Korisnicko ime je vec registrovano.");
    }
  }

  if(count==0){
    var count = await Preduzece.find({korime:req.body.korime}).countDocuments();
    if(count!=0){
      res.json("Korisnicko ime je vec registrovano.");
    }
  }

  if(count==0){
    polj.save();
    res.json("Uspesno napravljen nalog za poljoprivrednika.");
  }
  }}
  catch(err){
    res.json(err.message )
  }
  });


  router.post("/addpreduzece/",async function(req,res){
    try{
      var pred = new Preduzece({
        naziv:req.body.naziv,
        korime:req.body.korime,
        lozinka:req.body.lozinka,
        datum:req.body.datum,
        mesto:req.body.mesto,
        email:req.body.email
        });
        var counta = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
        if(counta==0){
          res.json("Pogresni kredencijali administratora.");
        }
        else{
    var count = await Administrator.find({korime:req.body.korime}).countDocuments();
      if(count!=0){
        res.json("Korisnicko ime je vec registrovano.");
      }

    if(count==0){
      var count = await Poljoprivrednik.find({korime:req.body.korime}).countDocuments();
      if(count!=0){
        res.json("Korisnicko ime je vec registrovano.");
      }
    }

    if(count==0){
      var count = await Preduzece.find({korime:req.body.korime}).countDocuments();
      if(count!=0){
        res.json("Korisnicko ime je vec registrovano.");
      }
    }

    if(count==0){
      pred.save();
      res.json("Uspesno napravljen nalog za preduzece.");
    }
    }}
    catch(err){
      res.json( err.message )
    }
    });




    router.post("/login",async function(req,res){
      try{
        var count = await Administrator.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count!=0){
        res.json("Admin " + req.body.korime + " uspesno ulogovan.");
      }

    if(count==0){
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count!=0){
       res.json("Poljoprivrednik " + req.body.korime + " uspesno ulogovan.")
      }
    }

    if(count==0){
      var count = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count!=0){
        res.json("Preduzece " + req.body.korime + " uspesno ulogovan.")
      }
    }

    if(count==0){
      res.json( "Pogresna lozinka ili korisnicko ime." )
    }
      }
      catch(err){
        res.json( err.message );
      }
    });


    router.post("/changepassword",async function(req,res){
      try{
        var count1 = await Administrator.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        var count2 = await Preduzece.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        var count3 = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
        if(count1!=0 || count2!=0 || count3!=0){
        await Preduzece.update({korime:req.body.korime},{lozinka:req.body.novalozinka});
        await Administrator.update({korime:req.body.korime},{lozinka:req.body.novalozinka});
        await Poljoprivrednik.update({korime:req.body.korime},{lozinka:req.body.novalozinka});
        res.json("Uspesno promenjena lozinka!");
      }
      else{
        res.json("Stara lozinka/korisnicko ime nisu tacni!");
      }
      }
      catch(err){
        res.json( err.message );
      }
    });


    router.post("/regpreduzece/",async function(req,res){
      try{
        var zahpred = new zahtevPreduzeca({
          naziv:req.body.naziv,
          korime:req.body.korime,
          lozinka:req.body.lozinka,
          datum:req.body.datum,
          mesto:req.body.mesto,
          email:req.body.email
          });

      var count = await Administrator.find({korime:req.body.korime}).countDocuments();
        if(count!=0){
          res.json("Korisnicko ime je vec registrovano.");
        }

      if(count==0){
        var count = await Poljoprivrednik.find({korime:req.body.korime}).countDocuments();
        if(count!=0){
          res.json("Korisnicko ime je vec registrovano.");
        }
      }

      if(count==0){
        var count = await Preduzece.find({korime:req.body.korime}).countDocuments();
        if(count!=0){
          res.json("Korisnicko ime je vec registrovano.");
        }
      }

      if(count==0){
        var count = await zahtevPreduzeca.find({korime:req.body.korime}).countDocuments();
        if(count!=0){
          res.json("Korisnicko ime je vec registrovano.");
        }
      }
      if(count==0){
        var count = await zahtevPoljoprivrednika.find({korime:req.body.korime}).countDocuments();
        if(count!=0){
          res.json("Korisnicko ime je vec registrovano.");
        }
      }

      if(count==0){
        zahpred.save();
        res.json("Vas zahtev je poslat administratoru na odobravanje.");
      }
      }
      catch(err){
        res.json( err.message )
      }
      });


      router.post("/regpoljoprivrednik/",async function(req,res){
        try{
          var zahpoljo = new zahtevPoljoprivrednika({
            ime:req.body.ime,
            prezime:req.body.prezime,
            korime:req.body.korime,
            lozinka:req.body.lozinka,
            datum:req.body.datum,
            mesto:req.body.mesto,
            email:req.body.email,
            telefon:req.body.telefon
            });

        var count = await Administrator.find({korime:req.body.korime}).countDocuments();
          if(count!=0){
            res.json("Korisnicko ime je vec registrovano.");
          }

        if(count==0){
          var count = await Poljoprivrednik.find({korime:req.body.korime}).countDocuments();
          if(count!=0){
            res.json("Korisnicko ime je vec registrovano.");
          }
        }

        if(count==0){
          var count = await Preduzece.find({korime:req.body.korime}).countDocuments();
          if(count!=0){
            res.json("Korisnicko ime je vec registrovano.");
          }
        }

        if(count==0){
          var count = await zahtevPreduzeca.find({korime:req.body.korime}).countDocuments();
          if(count!=0){
            res.json("Korisnicko ime je vec registrovano.");
          }
        }
        if(count==0){
          var count = await zahtevPoljoprivrednika.find({korime:req.body.korime}).countDocuments();
          if(count!=0){
            res.json("Korisnicko ime je vec registrovano.");
          }
        }

        if(count==0){
          zahpoljo.save();
          res.json("Vas zahtev je poslat administratoru na odobravanje.");
        }
        }
        catch(err){
          res.json( err.message );
        }
        });




router.post("/getadministratori",async (req,res)=>{
try{
    var count = await Administrator.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
else{
const administrators =await Administrator.find().select("-__v").select("-_id");
res.json(administrators);
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});


router.post("/getpoljoprivrednici",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
const poljoprivrednici =await Poljoprivrednik.find().select("-__v").select("-_id");
res.json(poljoprivrednici);
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});



router.post("/getpreduzeca",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
const preduzeca =await Preduzece.find().select("-__v").select("-_id");
res.json(preduzeca);
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});


router.post("/getzahtevipreduzeca",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
const preduzeca =await zahtevPreduzeca.find().select("-__v").select("-_id");
res.json(preduzeca);
}}
catch(err){
  res.json( "Doslo je do greske." );
}
});



router.post("/getzahtevipoljoprivrednika",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
const polj =await zahtevPoljoprivrednika.find().select("-__v").select("-_id");
res.json(polj);
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});


router.post("/deletezahtevpoljoprivrednika",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await zahtevPoljoprivrednika.deleteOne({korime:req.body.korimepoljoprivrednika});
res.json("Uspesno obrisan zahtev.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});


router.post("/deletezahtevpreduzeca",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await zahtevPreduzeca.deleteOne({korime:req.body.korimepreduzeca});
res.json("Uspesno obrisan zahtev.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});


router.post("/deletepoljoprivrednika",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await Poljoprivrednik.deleteOne({korime:req.body.korimepoljoprivrednika});
await Rasadnik.deleteMany({korime:req.body.korimepoljoprivrednika});
await Sadnica.deleteMany({poljoprivrednik:req.body.korimepoljoprivrednika});
await Preparat.deleteMany({poljoprivrednik:req.body.korimepoljoprivrednika});
res.json("Uspesno obrisan korisnik.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});

router.post("/deletepreduzece",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await Preduzece.deleteOne({korime:req.body.korimepreduzeca});
await Sadnica.deleteMany({pred:req.body.korimepreduzeca,poljoprivrednik:null,rasadnik:null});
await Preparat.deleteMany({pred:req.body.korimepreduzeca,poljoprivrednik:null,rasadnik:null});
res.json("Uspesno obrisan korisnik.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});

router.post("/deleteadmin",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await Administrator.deleteOne({korime:req.body.korimeadministratora});
res.json("Uspesno obrisan korisnik.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});

/************************** */
router.post("/modpoljoprivrednika",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await Poljoprivrednik.update({korime:req.body.korime},{lozinka:req.body.lozinka,ime:req.body.ime,prezime:req.body.prezime,
datum:req.body.datum,mesto:req.body.mesto,email:req.body.email,telefon:req.body.telefon});
res.json("Uspesno modifikovan korisnik.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});

router.post("/modpreduzece",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await Preduzece.update({korime:req.body.korime},{naziv:req.body.naziv,lozinka:req.body.lozinka,datum:req.body.datum,mesto:req.body.mesto,
email:req.body.email});
res.json("Uspesno modifikovan korisnik.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});

router.post("/modadmin",async (req,res)=>{
  try{
    var count = await Administrator.find({korime:req.body.admkorime,lozinka:req.body.admlozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali administratora.");
    }
    else{
await Administrator.update({korime:req.body.korime},{lozinka:req.body.lozinka});
res.json("Uspesno modifikovan korisnik.");
}}
catch(err){
  res.json( "Doslo je do greske." )
}
});



    module.exports=router;
