var mongoose = require("mongoose");
var express = require("express");
var router = express.Router();

var Rasadnik=require("./models/rasadnik");
var Poljoprivrednik=require("./models/poljoprivrednik");
var Narudzbina = require("./models/narudzbina");
var Sadnica = require("./models/sadnica");
var Preparat = require("./models/preparat");
var Komentar = require("./models/komentar");


router.post("/addrasadnik/",async function(req,res){
  try{
      var counta = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(counta==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
      else{
      var countb = await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}).countDocuments();
      if(countb!=0){
        res.json("Rasadnik sa ovim imenom vec postoji.");
      }
  else{
    var ras =new Rasadnik ({
      korime:req.body.korime,
      naziv:req.body.naziv,
      mesto:req.body.mesto,
      brzas:0,
      bruk:req.body.bruk,
      voda:200,
      temp:"18.0"
    });
    await ras.save();
    res.json("Uspesno dodat nov rasadnik.");
    }}}
    catch(err){
      res.json(err.message);
    }
 });

 router.post("/getrasadnici",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
var rasadnici = await Rasadnik.find({korime:req.body.korime}).select("-__v").select("-_id").select("-korime");
res.json(rasadnici);
}}
catch(err){
  res.json( "Doslo je do greske." );
}
});

router.post("/rasadnikinctemp",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
var rasadnik = (await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}))[0];
await Rasadnik.updateOne({korime:req.body.korime,naziv:req.body.naziv},{temp:parseFloat(rasadnik.temp)+1.0});
rasadnik = await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}).select("-__v").select("-_id").select("-korime");
res.json(rasadnik[0]);
}}
catch(err){
  res.json( err.message );
}
});

router.post("/rasadnikdectemp",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
var rasadnik = (await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}))[0];
await Rasadnik.updateOne({korime:req.body.korime,naziv:req.body.naziv},{temp:parseFloat(rasadnik.temp)-1.0});
rasadnik = await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}).select("-__v").select("-_id").select("-korime");
res.json(rasadnik[0]);
}}
catch(err){
  res.json( err.message );
}
});

router.post("/rasadnikincvoda",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
var rasadnik = (await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}))[0];
await Rasadnik.updateOne({korime:req.body.korime,naziv:req.body.naziv},{voda:rasadnik.voda+1});
rasadnik = await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}).select("-__v").select("-_id").select("-korime");
res.json(rasadnik[0]);
}}
catch(err){
  res.json( err.message );
}
});

router.post("/rasadnikdecvoda",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
var rasadnik = (await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}))[0];
await Rasadnik.updateOne({korime:req.body.korime,naziv:req.body.naziv},{voda:rasadnik.voda-1});
rasadnik = await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}).select("-__v").select("-_id").select("-korime");
res.json(rasadnik[0]);
}}
catch(err){
  res.json( err.message );
}
});

router.post("/getrasadnik",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
var rasadnik = await Rasadnik.find({korime:req.body.korime,naziv:req.body.naziv}).select("-__v").select("-_id").select("-korime");
res.json(rasadnik[0]);
}}
catch(err){
  res.json( err.message );
}
});



router.post("/addnarudzbina",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("-1");
    }
    else{
      count = await Rasadnik.find({naziv:req.body.rasadnik}).countDocuments();
      if(count ==0) {
        res.json("0");
      }
      else{
      var narudzbinaid=0;
      var narudzbine = await Narudzbina.find();
narudzbine.forEach(async (val)=>{
  if(val.id>narudzbinaid) narudzbinaid=val.id;
});
narudzbinaid+=1;
var nar = new Narudzbina({
id:narudzbinaid,
poljoprivrednik:req.body.korime,
pred:req.body.pred,
rasadnik:req.body.rasadnik,
datum:new Date(),
status:"Na odobravanju"
});
await nar.save();
res.json(narudzbinaid);
}}}
catch(err){
  res.json("-1");
}
});


router.post("/addnar_sadnica",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
      var nar = await Narudzbina.find({id:req.body.narudzbinaid});
      count = nar.length;

      if(count==0){
        res.json("Narudzbina ne postoji.");
      }
      else{
        var count = await Sadnica.find({naziv:req.body.naziv,pred:req.body.pred,narudzbina:null}).countDocuments();
        var sadnice = await Sadnica.find({naziv:req.body.naziv,pred:req.body.pred,narudzbina:null});
        var sad=sadnice[0];
        if(count==0){
          res.json("Data sadnica ne postoji.");
        }
        else if(sad.kolicina<req.body.kolicina){
          res.json("Nemoguce dodati ovu kolicinu sadnica.");
        }
        else if(req.body.pred!=nar[0].pred){
          res.json("Ne mozete staviti proizvode drugih preduzeca u ovu narudzbinu.");
        }
        else{
          var ostatak = sad.kolicina-req.body.kolicina;
          var sadnice2 = await Sadnica.find({naziv:req.body.naziv,pred:req.body.pred,narudzbina:req.body.narudzbinaid});
          if(ostatak!=0 && sadnice2.length==0){
            var nova_sad = new Sadnica({naziv:sad.naziv,pred:sad.pred,cena:sad.cena,kolicina:req.body.kolicina,poljoprivrednik:null,rasadnik:null,pozicija:null,trenrast:0,maxrast:sad.maxrast,narudzbina:req.body.narudzbinaid})
            await Sadnica.updateOne({naziv:sad.naziv,pred:sad.pred,narudzbina:null},{kolicina:ostatak});
            await nova_sad.save();
          }
          else if (ostatak==0 && sadnice2.length==0){
            await Sadnica.updateOne({naziv:sad.naziv,pred:sad.pred,narudzbina:null},{narudzbina:req.body.narudzbinaid});
          }
          else if (ostatak!=0 && sadnice2.length!=0){
            var novakol = req.body.kolicina+sadnice2[0].kolicina;
            await Sadnica.updateOne({naziv:sad.naziv,pred:sad.pred,narudzbina:null},{kolicina:ostatak});
            await Sadnica.updateOne({naziv:sad.naziv,pred:sad.pred,narudzbina:req.body.narudzbinaid},{kolicina:novakol});
          }
          else{
            var novakol = req.body.kolicina+sadnice2[0].kolicina;
            await Sadnica.updateOne({naziv:sad.naziv,pred:sad.pred,narudzbina:req.body.narudzbinaid},{kolicina:novakol});
            await Sadnica.deleteOne({naziv:sad.naziv,pred:sad.pred,narudzbina:null});
          }
          res.json("Uspesno dodate sadnice na narudzbinu.");
        }
      }

}}
catch(err){
  res.json( err.message );
}
});


router.post("/addnar_preparat",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
      var nar = await Narudzbina.find({id:req.body.narudzbinaid});
      count = nar.length;

      if(count==0){
        res.json("Narudzbina ne postoji.");
      }
      else{
        var count = await Preparat.find({naziv:req.body.naziv,pred:req.body.pred,narudzbina:null}).countDocuments();
        var preps = await Preparat.find({naziv:req.body.naziv,pred:req.body.pred,narudzbina:null});
        var prep=preps[0];
        if(count==0){
          res.json("Dat preparat ne postoji.");
        }
        else if(prep.kolicina<req.body.kolicina){
          res.json("Nemoguce dodati ovu kolicinu preparata.");
        }
        else if(req.body.pred!=nar[0].pred){
          res.json("Ne mozete staviti proizvode drugih preduzeca u ovu narudzbinu.");
        }
        else{
          var preps2 = await Preparat.find({naziv:req.body.naziv,pred:req.body.pred,narudzbina:req.body.narudzbinaid});
          var ostatak = prep.kolicina-req.body.kolicina;
          if(ostatak!=0 && preps2.length==0){
            var novi_prep = new Preparat({naziv:prep.naziv,pred:prep.pred,cena:prep.cena,kolicina:req.body.kolicina,poljoprivrednik:null,rasadnik:null,ubrzavanje:prep.ubrzavanje,narudzbina:req.body.narudzbinaid})
            await Preparat.updateOne({naziv:prep.naziv,pred:prep.pred,narudzbina:null},{kolicina:ostatak});
            await novi_prep.save();
          }
          else if (ostatak==0 && preps2.length==0){
            await Preparat.updateOne({naziv:prep.naziv,pred:prep.pred,narudzbina:null},{narudzbina:req.body.narudzbinaid});
          }
          else if(ostatak!=0 && preps2.length!=0){
            var novakol = req.body.kolicina+preps2[0].kolicina;
            await Preparat.updateOne({naziv:prep.naziv,pred:prep.pred,narudzbina:null},{kolicina:ostatak});
            await Preparat.updateOne({naziv:prep.naziv,pred:prep.pred,narudzbina:req.body.narudzbinaid},{kolicina:novakol});
          }
          else{
            var novakol = req.body.kolicina+preps2[0].kolicina;
            await Preparat.updateOne({naziv:prep.naziv,pred:prep.pred,narudzbina:req.body.narudzbinaid},{kolicina:novakol});
            await Preparat.deleteOne({naziv:prep.naziv,pred:prep.pred,narudzbina:null});
          }
          res.json("Uspesno dodati preparati na narudzbinu.");
        }
      }
}}
catch(err){
  res.json( err.message );
}
});



router.post("/removenarudzbina",async (req,res)=>{
  try{
    var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
    if(count==0){
      res.json("Pogresni kredencijali poljoprivrednika.");
    }
    else{
      count = await Narudzbina.find({id:req.body.narudzbinaid,status:"Na odobravanju"}).countDocuments();
      if(count==0){
        res.json("Narudzbina ne postoji.");
      }
      else{
        var preps=await Preparat.find({narudzbina:req.body.narudzbinaid});
        var sads=await Sadnica.find({narudzbina:req.body.narudzbinaid});

        preps.forEach( async (val) => {
          var count2=await Preparat.find({naziv:val.naziv,pred:val.pred,narudzbina:null}).countDocuments();
          var prep2=(await Preparat.find({naziv:val.naziv,pred:val.pred,narudzbina:null}))[0];
          if (count2==0){
           await  Preparat.updateOne({naziv:val.naziv,pred:val.pred},{narudzbina:null});
          }
          else{
            var novakol=prep2.kolicina+val.kolicina;
            await  Preparat.updateOne({naziv:val.naziv,pred:val.pred,narudzbina:null},{kolicina:novakol});
            await  Preparat.deleteOne(val);
          }
        });

        sads.forEach( async (val) => {
          var count2=await Sadnica.find({naziv:val.naziv,pred:val.pred,narudzbina:null}).countDocuments();
          var sads2=(await Sadnica.find({naziv:val.naziv,pred:val.pred,narudzbina:null}))[0];
          if (count2==0){
           await  Sadnica.updateOne({naziv:val.naziv,pred:val.pred,kolicina:val.kolicina},{narudzbina:null});
          }
          else{
            var novakol=sads2.kolicina+val.kolicina;
            await Sadnica.updateOne({naziv:val.naziv,pred:val.pred,narudzbina:null},{kolicina:novakol});
            await Sadnica.deleteOne(val);
          }
        });


         await Narudzbina.deleteOne({id:req.body.narudzbinaid});
         res.json("Uspesno obrisana narudzbina.");

      }
    }
  }
  catch(err){
    res.json( err.message );
  }
  });


  router.post("/getsadnice",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
      else{
        var sadnice = await Sadnica.find({narudzbina:null}).select("-__v").select("-_id");
  res.json(sadnice);
  }}
  catch(err){
    res.json( "Doslo je do greske." );
  }
  });

  router.post("/getpreparati",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
      else{
  var prep = await Preparat.find({narudzbina:null}).select("-__v").select("-_id");
  res.json(prep);
  }}
  catch(err){
    res.json("Doslo je do greske");
  }
  });

  router.post("/getnarudzbine",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
      else{
  var nar = await Narudzbina.find({poljoprivrednik:req.body.korime,$or:[{status:"Na odobravanju"},{status:"Na cekanju"},{status:"U transportu"}]}).select("-__v").select("-_id");
  res.json(nar);
  }}
  catch(err){
    res.json("Doslo je do greske");
  }
  });



  router.post("/getmag_sadnice",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  count = await Rasadnik.find({naziv:req.body.rasadnik}).countDocuments();
  if(count==0){
    res.json("Ne postoji dati rasadnik.");
  }
  else{
  var sad = await Sadnica.find({poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik,pozicija:0,trenrast:0}).select("-__v").select("-_id");;
  res.json(sad);
  }}}
  catch(err){
    res.json("Doslo je do greske");
  }
  });

  router.post("/getmag_preparati",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  count = await Rasadnik.find({naziv:req.body.rasadnik}).countDocuments();
  if(count==0){
    res.json("Ne postoji dati rasadnik.");
  }
  else{
  var prep = await Preparat.find({poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik}).select("-__v").select("-_id");;
  res.json(prep);
  }}}
  catch(err){
    res.json("Doslo je do greske");
  }
  });




  router.post("/plantsadnica",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  sadnica = await Sadnica.find({poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik,naziv:req.body.naziv,pred:req.body.pred,pozicija:0,trenrast:0});
  count=sadnica.length;
  if(count==0){
    res.json("Ne postoji data sadnica.");
  }
  else{
    count = await Sadnica.find({poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik,pozicija:req.body.pozicija}).countDocuments();
    if(count!=0){
      res.json("Neka sadnica je vec zasadjena na tom mestu.");
    }
    else{
      rasadnik =await  Rasadnik.find({naziv:req.body.rasadnik,korime:req.body.korime});

      if(rasadnik[0].bruk<req.body.pozicija || req.body.pozicija<=0){
        res.json("Neregularna pozicija za smestanje sadnice.");
      }
      else{
      var ostatak = sadnica[0].kolicina - 1 ;
      if(ostatak == 0){
        await Sadnica.updateOne(sadnica[0],{pozicija:req.body.pozicija});
      }
      else{
        await Sadnica.updateOne(sadnica[0],{kolicina:ostatak});
        var novaSad = new Sadnica({
          naziv:sadnica[0].naziv,
          pred:sadnica[0].pred,
          cena:sadnica[0].cena,
          kolicina:1,
          poljoprivrednik:sadnica[0].poljoprivrednik,
          rasadnik:sadnica[0].rasadnik,
          pozicija:req.body.pozicija,
          trenrast:0,
          maxrast:sadnica[0].maxrast,
          narudzbina:sadnica[0].narudzbina});
          await novaSad.save();
        }
      var brz = rasadnik[0].brzas+1;
      await Rasadnik.updateOne(rasadnik[0],{brzas:brz});
      res.json("Uspesno zasadjena sadnica.");
    }}
  }}}
  catch(err){
    res.json(err.message);
  }
  });


  router.post("/usepreparat",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  var sad = await Sadnica.find({poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik,pozicija:req.body.pozicija});
  count = sad.length;
  if(count==0){
    res.json("Ne postoji sadnica zasadjena na datoj poziciji.");
  }
  else{
    var prep = await Preparat.find({pred:req.body.pred,naziv:req.body.naziv,poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik});
    count = prep.length;
    if(count==0){
      res.json("Dati preparat ne postoji.");
    }
    else{
      var rast=sad[0].trenrast + prep[0].ubrzavanje;
      if(rast>sad[0].maxrast) rast=sad[0].maxrast;
      await Sadnica.updateOne(sad[0],{trenrast:rast});
      var kol = prep[0].kolicina-1;
      if(kol==0){
        await Preparat.deleteOne(prep[0]);
      }
      else{
        await Preparat.updateOne(prep[0],{kolicina:kol});
      }
      res.json("Uspesno iskoriscen preparat na sadnici.");
    }
  }}}
  catch(err){
    res.json(err.message);
  }
  });

  router.post("/removesadnica",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  var sad = await Sadnica.find({poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik,pozicija:req.body.pozicija});
  count = sad.length;
  if(count==0){
    res.json("Ne postoji data sadnica.");
  }
  else{
    if(sad[0].trenrast==sad[0].maxrast){
      await Sadnica.updateOne(sad[0],{pozicija:0});
      var ras = await Rasadnik.find({naziv:req.body.rasadnik,korime:req.body.korime});
      var brzasnew = ras[0].brzas-1;
      await Rasadnik.updateOne(ras[0],{brzas:brzasnew});
      res.json("Uspesno uklonjena sadnica.");
    }
    else{
      res.json("Sadnica nije jos uvek izrasla.");
    }
  }}}
  catch(err){
    res.json("Doslo je do greske");
  }
  });

  router.post("/getplantedsadnice",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  count = await Rasadnik.find({naziv:req.body.rasadnik}).countDocuments();
  if(count==0){
    res.json("Ne postoji dati rasadnik.");
  }
  else{
  var sad = await Sadnica.find({pozicija:{$ne:0},poljoprivrednik:req.body.korime,rasadnik:req.body.rasadnik});
    res.json(sad);
  }}}
  catch(err){
    res.json("Doslo je do greske");
  }
  });



  router.post("/addkomentarsad",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  count = await Sadnica.find({naziv:req.body.naziv,pred:req.body.pred}).countDocuments();
  if(count==0){
    res.json("Ne postoji data sadnica.");
  }
  else{
  count = await Sadnica.find({naziv:req.body.naziv,pred:req.body.pred,poljoprivrednik:req.body.korime}).countDocuments();
  if(count==0){
    res.json("Poljoprivrednik nije kupio datu sadnicu.");
  }
  else{
  count = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,poljoprivrednik:req.body.korime,tip:"S"}).countDocuments();
  if(count!=0){
    res.json("Vec postoji komentar na dati proizvod.");
  }
  else{
  var kom = new Komentar({naziv:req.body.naziv,
    sadrzaj:req.body.sadrzaj,
    ocena:req.body.ocena,
    poljoprivrednik:req.body.korime,
    pred:req.body.pred,
    tip:"S"});
    await kom.save();
  res.json("Uspesno sacuvan komentar.");
  }}}}}
  catch(err){
    res.json("Doslo je do greske");
  }
  });




  router.post("/addkomentarprep",async (req,res)=>{
    try{

      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
  count = await Preparat.find({naziv:req.body.naziv,pred:req.body.pred}).countDocuments();
  if(count==0){
    res.json("Ne postoji dat preparat.");
  }
  else{
  count = await Preparat.find({naziv:req.body.naziv,pred:req.body.pred,poljoprivrednik:req.body.korime}).countDocuments();
  if(count==0){
    res.json("Poljoprivrednik nije kupio dat preparat.");
  }
  else{
  count = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,poljoprivrednik:req.body.korime,tip:"P"}).countDocuments();
  if(count!=0){
    res.json("Vec postoji komentar na dati proizvod.");
  }
  else{
  var kom = new Komentar({naziv:req.body.naziv,
    sadrzaj:req.body.sadrzaj,
    ocena:req.body.ocena,
    poljoprivrednik:req.body.korime,
    pred:req.body.pred,
    tip:"P"});
    await kom.save();
  res.json("Uspesno sacuvan komentar.");
  }}}}}
  catch(err){
    res.json("Doslo je do greske");
  }
  });


  router.post("/getkomentarisad",async (req,res)=>{
    console.log("lol");
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
      var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,tip:"S"}).select("-__v").select("-_id");
      res.json(komentari);
 }}
  catch(err){
    res.json("Doslo je do greske");
  }
  });


  router.post("/getkomentariprep",async (req,res)=>{
    try{
      console.log("lol2");
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json("Pogresni kredencijali poljoprivrednika.");
      }
 else{
      var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,tip:"P"}).select("-__v").select("-_id");
      res.json(komentari);
 }}
  catch(err){
    res.json("Doslo je do greske");
  }
  });



  router.post("/getocenasad",async (req,res)=>{
    try{

      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json(-1);
      }
 else{
      var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,tip:"S"});
      if(komentari.length==0){
        res.json(0);
      }
      else{
        let ocena=0; let ukupanbrojocena=komentari.length;
        komentari.forEach((el)=>{
          ocena+=el.ocena;
        });

        res.json(Math.round(ocena/ukupanbrojocena));
      }
 }}
  catch(err){
    res.json(-1);
  }
  });

  router.post("/getocenaprep",async (req,res)=>{
    try{
      var count = await Poljoprivrednik.find({korime:req.body.korime,lozinka:req.body.lozinka}).countDocuments();
      if(count==0){
        res.json(-1);
      }
 else{
      var komentari = await Komentar.find({naziv:req.body.naziv,pred:req.body.pred,tip:"P"});
      if(komentari.length==0){
        res.json(0);
      }
      else{
        let ocena=0; let ukupanbrojocena=komentari.length;
        komentari.forEach((el)=>{
          ocena+=el.ocena;
        });
        res.json(Math.round(ocena/ukupanbrojocena));
      }
 }}
  catch(err){
    res.json(-1);
  }
  });



 module.exports=router;
