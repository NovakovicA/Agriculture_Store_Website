import { Komentar } from './app/models/komentar';
import { Narudzbina } from './app/models/narudzbina';
import { Preparat } from './app/models/preparat';
import { Sadnica } from './app/models/sadnica';
import { Rasadnik } from './app/models/rasadnik';
import { Poljoprivrednik } from './app/models/poljoprivrednik';
import { Administrator } from './app/models/administrator';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, ObservableInput } from 'rxjs';
import { Preduzece } from './app/models/preduzece';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
// GENERAL
loginURL:string="http://localhost:3000/login";
changePassURL:string="http://localhost:3000/changepassword";

getAdministratoriURL:string="http://localhost:3000/getadministratori";
getPoljoprivredniciURL:string="http://localhost:3000/getpoljoprivrednici";
getPreduzecaURL:string="http://localhost:3000/getpreduzeca";
getzahPreduzecaURL:string="http://localhost:3000/getzahtevipreduzeca";
getzahPoljoprivrednikaURL:string="http://localhost:3000/getzahtevipoljoprivrednika";

regPoljoprivrednikURL:string="http://localhost:3000/regpoljoprivrednik";
regPreduzeceURL:string="http://localhost:3000/regpreduzece";

delregPoljoprivrednikURL:string="http://localhost:3000/deletezahtevpoljoprivrednika";
delregPreduzeceURL:string="http://localhost:3000/deletezahtevpreduzeca";

addAdminURL:string="http://localhost:3000/addadmin/";
addPreduzeceURL:string="http://localhost:3000/addpreduzece";
addPoljoprivrednikURL:string="http://localhost:3000/addpoljoprivrednik";

deleteAdminURL:string="http://localhost:3000/deleteadmin";
deletePreduzeceURL:string="http://localhost:3000/deletepreduzece";
deletePoljoprivrednikaURL:string="http://localhost:3000/deletepoljoprivrednika";


modAdminURL:string="http://localhost:3000/modadmin/";
modPreduzeceURL:string="http://localhost:3000/modpreduzece";
modPoljoprivrednikURL:string="http://localhost:3000/modpoljoprivrednika";

constructor(private http:HttpClient) { }

login(korime:string, lozinka:string):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka
  }
 return this.http.post<string>(this.loginURL,data);
}

promenaLozinke(korime:string, lozinka:string, novalozinka:string):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "novalozinka":novalozinka
  }
  return this.http.post<string>(this.changePassURL,data);
}

dohvatiAdmine(korime:string,lozinka:string):Observable<Administrator[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
  }
  return this.http.post<Administrator[]>(this.getAdministratoriURL,data);
}

dohvatiPoljoprivrednike(korime:string,lozinka:string):Observable<Poljoprivrednik[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
  }
  return this.http.post<Poljoprivrednik[]>(this.getPoljoprivredniciURL,data);
}

dohvatiPreduzeca(korime:string,lozinka:string):Observable<Preduzece[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
  }
  return this.http.post<Preduzece[]>(this.getPreduzecaURL,data);
}

dohvatiZahPoljoprivrednika(korime:string,lozinka:string):Observable<Poljoprivrednik[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
  }
  return this.http.post<Poljoprivrednik[]>(this.getzahPoljoprivrednikaURL,data);
}

dohvatiZahPreduzeca(korime:string,lozinka:string):Observable<Preduzece[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
  }
  return this.http.post<Preduzece[]>(this.getzahPreduzecaURL,data);
}

registrujPreduzece(pred:Preduzece):Observable<string>{
  return this.http.post<string>(this.regPreduzeceURL,pred);
}

registrujPoljoprivrednika(polj:Poljoprivrednik):Observable<string>{
  return this.http.post<string>(this.regPoljoprivrednikURL,polj);
}

obrisiZahtevPoljoprivrednika(korime:string,lozinka:string,korimepoljoprivrednika:string):Observable<string>{
  let data={
    "admkorime":korime,
    "admlozinka":lozinka,
    "korimepoljoprivrednika":korimepoljoprivrednika
  }
  return this.http.post<string>(this.delregPoljoprivrednikURL,data);
}

obrisiZahtevPreduzeca(korime:string,lozinka:string,korimepreduzeca:string):Observable<string>{
  let data={
    "admkorime":korime,
    "admlozinka":lozinka,
    "korimepreduzeca":korimepreduzeca
  }
  return this.http.post<string>(this.delregPreduzeceURL,data);
}

dodajAdmina(admin:Administrator,korime:string,lozinka:string):Observable<string>{
let data={
"korime":admin.korime,
"lozinka":admin.lozinka,
"admkorime":korime,
"admlozinka":lozinka
}
return this.http.post<string>(this.addAdminURL,data);
}

dodajPoljoprivrednika(polj:Poljoprivrednik,korime:string,lozinka:string):Observable<string>{
  let data={
    "ime":polj.ime,
    "prezime":polj.prezime,
    "korime":polj.korime,
    "lozinka":polj.lozinka,
    "datum":polj.datum,
    "mesto":polj.mesto,
    "email":polj.email,
    "telefon":polj.telefon,
    "admkorime":korime,
    "admlozinka":lozinka
  }
    return this.http.post<string>(this.addPoljoprivrednikURL,data);
    }

    dodajPreduzece(pred:Preduzece,korime:string,lozinka:string):Observable<string>{
      let data={
        "naziv":pred.naziv,
        "korime":pred.korime,
        "lozinka":pred.lozinka,
        "datum":pred.datum,
        "mesto":pred.mesto,
        "email":pred.email,
        "admkorime":korime,
        "admlozinka":lozinka
      }
        return this.http.post<string>(this.addPreduzeceURL,data);
        }

obrisiAdmina(korime:string,lozinka:string,korimeadministratora:string):Observable<string>{
let data={
  "admkorime":korime,
  "admlozinka":lozinka,
  "korimeadministratora":korimeadministratora
}
return this.http.post<string>(this.deleteAdminURL,data);
}

obrisiPoljoprivrednika(korime:string,lozinka:string,korimepoljoprivrednika:string):Observable<string>{
let data={
  "admkorime":korime,
  "admlozinka":lozinka,
  "korimepoljoprivrednika":korimepoljoprivrednika
}
return this.http.post<string>(this.deletePoljoprivrednikaURL,data);
}

obrisiPreduzece(korime:string,lozinka:string,korimepreduzeca:string):Observable<string>{
let data={
  "admkorime":korime,
  "admlozinka":lozinka,
  "korimepreduzeca":korimepreduzeca
}
return this.http.post<string>(this.deletePreduzeceURL,data);
}

modifikujAdmina(admin:Administrator,korime:string,lozinka:string):Observable<string>{
let data={
  "korime":admin.korime,
  "lozinka":admin.lozinka,
  "admkorime":korime,
  "admlozinka":lozinka
}
  return this.http.post<string>(this.modAdminURL,data);
  }


  modifikujPoljoprivrednika(polj:Poljoprivrednik,korime:string,lozinka:string):Observable<string>{
    let data={
      "ime":polj.ime,
      "prezime":polj.prezime,
      "korime":polj.korime,
      "lozinka":polj.lozinka,
      "datum":polj.datum,
      "mesto":polj.mesto,
      "email":polj.email,
      "telefon":polj.telefon,
      "admkorime":korime,
      "admlozinka":lozinka
    }
      return this.http.post<string>(this.modPoljoprivrednikURL,data);
      }

      modifikujPreduzece(pred:Preduzece,korime:string,lozinka:string):Observable<string>{
        let data={
          "naziv":pred.naziv,
          "korime":pred.korime,
          "lozinka":pred.lozinka,
          "datum":pred.datum,
          "mesto":pred.mesto,
          "email":pred.email,
          "admkorime":korime,
          "admlozinka":lozinka
        }
          return this.http.post<string>(this.modPreduzeceURL,data);
          }

//Poljoprivrednik
getRasadniciURL:string="http://localhost:3000/pp/getrasadnici/";
addRasadnikURL:string="http://localhost:3000/pp/addrasadnik/";
incTempRasadnikURL:string="http://localhost:3000/pp/rasadnikinctemp/";
decTempRasadnikURL:string="http://localhost:3000/pp/rasadnikdectemp/";
incVodaRasadnikURL:string="http://localhost:3000/pp/rasadnikincvoda/";
decVodaRasadnikURL:string="http://localhost:3000/pp/rasadnikdecvoda/";
getRasadnikURL:string="http://localhost:3000/pp/getrasadnik/";

getProdavaneSadniceURL:string="http://localhost:3000/pp/getsadnice";
getProdavaniPreparatiURL:string="http://localhost:3000/pp/getpreparati";
getNarudzbineSeljakaURL:string="http://localhost:3000/pp/getnarudzbine"
removeNarudzbinuSeljakaURL:string="http://localhost:3000/pp/removenarudzbina/";

addNarudzbinaURL:string="http://localhost:3000/pp/addnarudzbina/";
addNarPreparatURL:string="http://localhost:3000/pp/addnar_preparat/";
addNarSadnicaURL:string="http://localhost:3000/pp/addnar_sadnica/";

getMagSadniceURL:string="http://localhost:3000/pp/getmag_sadnice";
getMagPreparatiURL:string="http://localhost:3000/pp/getmag_preparati";
plantSadnicaURL:string="http://localhost:3000/pp/plantsadnica";
usePreparatURL:string="http://localhost:3000/pp/usepreparat";
removeZasSadnicaURL:string="http://localhost:3000/pp/removesadnica";
getPlantedSadniceURL:string="http://localhost:3000/pp/getplantedsadnice";

addKomentarSadURL:string="http://localhost:3000/pp/addkomentarsad";
addKomentarPrepURL:string="http://localhost:3000/pp/addkomentarprep";
getKomentariSadnicePPURL:string="http://localhost:3000/pp/getkomentarisad";
getKomentariPreparataPPURL:string="http://localhost:3000/pp/getkomentariprep";
getOcenaSadnicaPPURL:string="http://localhost:3000/pp/getocenasad";
getOcenaPreparatPPURL:string="http://localhost:3000/pp/getocenaprep";



dohvatiRasadnike(korime:string, lozinka:string):Observable<Rasadnik[]>{
let data={
  "korime":korime,
  "lozinka":lozinka
}
return this.http.post<Rasadnik[]>(this.getRasadniciURL,data);
}


dodajRasadnik(korime:string, lozinka:string, ras:Rasadnik):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":ras.naziv,
    "mesto":ras.mesto,
    "bruk":ras.bruk
  }
  return this.http.post<string>(this.addRasadnikURL,data);
}

incTemp(korime:string,lozinka:string,naziv:string):Observable<Rasadnik>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":naziv
  }
  return this.http.post<Rasadnik>(this.incTempRasadnikURL,data);
}

decTemp(korime:string,lozinka:string,naziv:string):Observable<Rasadnik>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":naziv
  }
  return this.http.post<Rasadnik>(this.decTempRasadnikURL,data);
}

incVoda(korime:string,lozinka:string,naziv:string):Observable<Rasadnik>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":naziv
  }
  return this.http.post<Rasadnik>(this.incVodaRasadnikURL,data);
}

decVoda(korime:string,lozinka:string,naziv:string):Observable<Rasadnik>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":naziv
  }
  return this.http.post<Rasadnik>(this.decVodaRasadnikURL,data);
}

dohvatiRasadnik(korime:string,lozinka:string,naziv:string):Observable<Rasadnik>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":naziv
  }
  return this.http.post<Rasadnik>(this.getRasadnikURL,data);
}

dohvatiProdavaneSadnice(korime:string,lozinka:string):Observable<Sadnica[]>
{
  let data={
    "korime":korime,
    "lozinka":lozinka
  }
  return this.http.post<Sadnica[]>(this.getProdavaneSadniceURL,data);
}

dohvatiProdavaniPreparati(korime:string,lozinka:string):Observable<Preparat[]>
{
  let data={
    "korime":korime,
    "lozinka":lozinka
  }
  return this.http.post<Preparat[]>(this.getProdavaniPreparatiURL,data);
}

dohvatiNarudzbineSeljaka(korime:string,lozinka:string):Observable<Narudzbina[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka
  }
  return this.http.post<Narudzbina[]>(this.getNarudzbineSeljakaURL,data);
}

ukloniNarudzbinu(korime:string,lozinka:string,id:Number):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "narudzbinaid":id
  }
  return this.http.post<string>(this.removeNarudzbinuSeljakaURL,data);
}


dodajNarudzbinu(korime:String,lozinka:string,r:string,p:string):Observable<Number>
{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "rasadnik":r,
    "pred":p
  }
  return this.http.post<Number>(this.addNarudzbinaURL,data);
}

dodajNarSadnicu(korime:String,lozinka:string,id:Number,sad:Sadnica):Observable<string>
{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "narudzbinaid":id,
    "naziv":sad.naziv,
    "pred":sad.pred,
    "kolicina":sad.kolicina
  }
  return this.http.post<string>(this.addNarSadnicaURL,data);
}

dodajNarPreparat(korime:String,lozinka:string,id:Number,p:Preparat):Observable<string>
{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "narudzbinaid":id,
    "naziv":p.naziv,
    "pred":p.pred,
    "kolicina":p.kolicina
  }
  return this.http.post<string>(this.addNarPreparatURL,data);
}

dohvatiMagSadnice(korime:string,lozinka:string,rasadnik:string):Observable<Sadnica[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "rasadnik":rasadnik
  }
  return this.http.post<Sadnica[]>(this.getMagSadniceURL,data);
}

dohvatiMagPreparate(korime:string,lozinka:string,rasadnik:string):Observable<Preparat[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "rasadnik":rasadnik
  }
  return this.http.post<Preparat[]>(this.getMagPreparatiURL,data);
}

posadiSadnicu(korime:string,lozinka:string,sad:Sadnica,ras:string,pozicija:Number):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "rasadnik":ras,
    "naziv":sad.naziv,
    "pred":sad.pred,
    "pozicija":pozicija
  }
  return this.http.post<string>(this.plantSadnicaURL,data);
}

iskoristiPreparat(korime:string,lozinka:string,prep:Preparat,ras:string,pozicija:Number):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "rasadnik":ras,
    "pozicija":pozicija,
    "naziv":prep.naziv,
    "pred":prep.pred
  }
  return this.http.post<string>(this.usePreparatURL,data);
}


ukloniZasSadnicu(korime:string,lozinka:string,ras:string,pozicija:Number):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "rasadnik":ras,
    "pozicija":pozicija
  }
  return this.http.post<string>(this.removeZasSadnicaURL,data);
}

dohvatiZasSadnice(korime:string,lozinka:string,ras:string):Observable<Sadnica[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "rasadnik":ras
  }
  return this.http.post<Sadnica[]>(this.getPlantedSadniceURL,data);
}

dodajKomentarSadnica(User:string,Pass:string,naziv:string,pred:string,sadrzaj:string,ocena:number):Observable<string>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred,
    "sadrzaj":sadrzaj,
    "ocena":ocena
  }
  return this.http.post<string>(this.addKomentarSadURL,data);
}

dodajKomentarPreparat(User:string,Pass:string,naziv:string,pred:string,sadrzaj:string,ocena:number):Observable<string>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred,
    "sadrzaj":sadrzaj,
    "ocena":ocena
  }
  return this.http.post<string>(this.addKomentarPrepURL,data);
}

dohvatiKomentareSadnicaPP(User:string,Pass:String,naziv:string,pred:string):Observable<Komentar[]>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<Komentar[]>(this.getKomentariSadnicePPURL,data);
}

dohvatiKomentarePreparataPP(User:string,Pass:String,naziv:string,pred:string):Observable<Komentar[]>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<Komentar[]>(this.getKomentariPreparataPPURL,data);
}

dohvatiOcenuSadnicePP(User:string,Pass:String,naziv:string,pred:string):Observable<number>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<number>(this.getOcenaSadnicaPPURL,data);
}


dohvatiOcenuPreparataPP(User:string,Pass:String,naziv:string,pred:string):Observable<number>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<number>(this.getOcenaPreparatPPURL,data);
}






//Preduzece
addSadnicaURL:string="http://localhost:3000/p/addsadnica/";
removeSadnicaURL:string="http://localhost:3000/p/removesadnica/";
modifySadnicaURL:string="http://localhost:3000/p/modifysadnica/";
getSadnicaURL:string="http://localhost:3000/p/getsadnice/";

addPreparatURL:string="http://localhost:3000/p/addpreparat/";
removePreparatURL:string="http://localhost:3000/p/removepreparat/";
modifyPreparatURL:string="http://localhost:3000/p/modifypreparat/";
getPreparatURL:string="http://localhost:3000/p/getpreparati/";

getNarudzbineURL:string="http://localhost:3000/p/getnarudzbine/";
getNarSadniceURL:string="http://localhost:3000/p/getnar_sadnice/";
getNarPreparateURL:string="http://localhost:3000/p/getnar_preparati/";
confirmNarudzbinaURL:string="http://localhost:3000/p/confirmnarudzbina/";
removeNarudzbinaURL:string="http://localhost:3000/p/removenarudzbina/";

getKomentariSadnicePURL:string="http://localhost:3000/p/getkomentarisad";
getKomentariPreparataPURL:string="http://localhost:3000/p/getkomentariprep";
getOcenaSadnicaPURL:string="http://localhost:3000/p/getocenasad";
getOcenaPreparatPURL:string="http://localhost:3000/p/getocenaprep";

getAllNarudzbineURL:string="http://localhost:3000/p/getsvenarudzbine"


dodajSadnicu(korime:string,lozinka:string,sadnica:Sadnica):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":sadnica.naziv,
    "cena":sadnica.cena,
    "kolicina":sadnica.kolicina,
    "maxrast":sadnica.maxrast
  }
  return this.http.post<string>(this.addSadnicaURL,data);
}


ukloniSadnicu(korime:string,lozinka:string,sadnica:Sadnica):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":sadnica.naziv
  }
  return this.http.post<string>(this.removeSadnicaURL,data);
}

modifikujSadnicu(korime:string,lozinka:string,sadnica:Sadnica):Observable<string>{
  let data={
"korime":korime,
"lozinka":lozinka,
"naziv":sadnica.naziv,
"cena":sadnica.cena,
"kolicina":sadnica.kolicina
  }
  return this.http.post<string>(this.modifySadnicaURL,data);
}

dohvatiSadnice(korime:string,lozinka:string):Observable<Sadnica[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka
  }
  return this.http.post<Sadnica[]>(this.getSadnicaURL,data);
}

dodajPreparat(korime:string,lozinka:string,prep:Preparat):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":prep.naziv,
    "cena":prep.cena,
    "kolicina":prep.kolicina,
    "ubrzavanje":prep.ubrzavanje
  }
  return this.http.post<string>(this.addPreparatURL,data);
}


ukloniPreparat(korime:string,lozinka:string,prep:Preparat):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":prep.naziv
  }
  return this.http.post<string>(this.removePreparatURL,data);
}

modifikujPreparat(korime:string,lozinka:string,prep:Preparat):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "naziv":prep.naziv,
    "kolicina":prep.kolicina,
    "cena":prep.cena
  }
  return this.http.post<string>(this.modifyPreparatURL,data);
}

dohvatiPreparate(korime:string,lozinka:string):Observable<Preparat[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka
  }
  return this.http.post<Preparat[]>(this.getPreparatURL,data);
}

dohvatiNarudzbine(korime:string,lozinka:string):Observable<Narudzbina[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka
  }
  return this.http.post<Narudzbina[]>(this.getNarudzbineURL,data);
}

dohvatiNarSadnice(korime:string,lozinka:string,nar:Number):Observable<Sadnica[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "narudzbinaid":nar
  }
  return this.http.post<Sadnica[]>(this.getNarSadniceURL,data);
}

dohvatiNarPreparate(korime:string,lozinka:string,nar:Number):Observable<Preparat[]>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "narudzbinaid":nar
  }
  return this.http.post<Preparat[]>(this.getNarPreparateURL,data);
}

potvrdiNarudzbinu(korime:string,lozinka:string,nar:Number):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "narudzbinaid":nar
  }
  return this.http.post<string>(this.confirmNarudzbinaURL,data);
}

izbrisiNarudzbinu(korime:string,lozinka:string,nar:Number):Observable<string>{
  let data={
    "korime":korime,
    "lozinka":lozinka,
    "narudzbinaid":nar
  }
  return this.http.post<string>(this.removeNarudzbinaURL,data);
}

dohvatiKomentareSadnicaP(User:string,Pass:String,naziv:string,pred:string):Observable<Komentar[]>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<Komentar[]>(this.getKomentariSadnicePURL,data);
}

dohvatiKomentarePreparataP(User:string,Pass:String,naziv:string,pred:string):Observable<Komentar[]>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<Komentar[]>(this.getKomentariPreparataPURL,data);
}

dohvatiOcenuSadniceP(User:string,Pass:String,naziv:string,pred:string):Observable<number>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<number>(this.getOcenaSadnicaPURL,data);
}


dohvatiOcenuPreparataP(User:string,Pass:String,naziv:string,pred:string):Observable<number>{
  let data={
    "korime":User,
    "lozinka":Pass,
    "naziv":naziv,
    "pred":pred
  }
  return this.http.post<number>(this.getOcenaPreparatPURL,data);
}


dohvatiSveNarudzbine(User:string,Pass:string):Observable<Narudzbina[]>{
  let data={
    "korime":User,
    "lozinka":Pass
  }
  return this.http.post<Narudzbina[]>(this.getAllNarudzbineURL,data);
}



}
