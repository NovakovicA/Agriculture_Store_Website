import { Preparat } from './../models/preparat';
import { ApiService } from './../../api.service';
import { Rasadnik } from './../models/rasadnik';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Sadnica } from '../models/sadnica';


@Component({
  selector: 'app-rasadnik',
  templateUrl: './rasadnik.component.html',
  styleUrls: ['./rasadnik.component.css']
})
export class RasadnikComponent implements OnInit {
  User:string;
  Pass:string;
  refresh;

  trenutniRasadnik:Rasadnik=null;
  magSadnice:Sadnica[]=[];
  magPreparati:Preparat[]=[];
  zasSadnice:Sadnica[]=[];

  zabranjenoSadjenje:number[]=[];


  arrayZaFor:number[]=[];
  selectedIndex:number=null;
  selectedSadnica:Sadnica=null;
  selectedMagSadnica:Sadnica=null;
  selectedMagPreparat:Preparat=null;

  sort:number=0;
  sortType:number=0;

  naziv:string="";
  proiz:string="";
  kol:string="";
  par:string="";
  koristiFilter=false;


  constructor(private router:Router,private api:ApiService) {
    this.refresh=setInterval(()=> {this.refreshujSve()}, 5000);
  }

  ngOnInit(): void {
    if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
    }

    if(localStorage.getItem("trenutniRasadnik")!=null){
    this.trenutniRasadnik=JSON.parse(localStorage.getItem("trenutniRasadnik"));}
    else{
      this.router.navigate(['/poljoprivrednik']);
    }
    let i:number=0;
    while(i<this.trenutniRasadnik.bruk) {this.arrayZaFor.push(0); i=i+1;}
    this.refreshujSve();
  }

  ngOnDestroy() {
    clearInterval(this.refresh);
  }

  odjava():void{
    localStorage.setItem("User",null);
    localStorage.setItem("Pass",null);
    this.router.navigate(['/login']);
  }

  promenaLozinke():void{
    localStorage.setItem("returnPage","/poljoprivrednik");
    this.router.navigate(['/promenalozinke']);
  }

  incTemp(){
    this.api.incTemp(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(res=>{
      this.trenutniRasadnik=res;
    });
  }

  decTemp(){
    this.api.decTemp(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(res=>{
      this.trenutniRasadnik=res;
    });
  }

  incVoda(){
    this.api.incVoda(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(res=>{
      this.trenutniRasadnik=res;
    });
  }

  decVoda(){
    this.api.decVoda(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(res=>{
      this.trenutniRasadnik=res;
    });
  }

  prodavnica():void{
    this.router.navigate(['/prodavnica']);
  }

  refreshujSve(){
    this.api.dohvatiRasadnik(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(data=>this.trenutniRasadnik=data);
    this.api.dohvatiMagSadnice(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(data=>{this.magSadnice=data; this.updateSelMagSad();});
    this.api.dohvatiMagPreparate(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(data=>{this.magPreparati=data; this.updateSelMagPrep();});
    this.api.dohvatiZasSadnice(this.User,this.Pass,this.trenutniRasadnik.naziv).subscribe(data=>{this.zasSadnice=data;
      this.arrayZaFor=[];
      let i:number=0;
      while(i<this.trenutniRasadnik.bruk) {this.arrayZaFor.push(0); i=i+1;}
      this.zasSadnice.forEach((el)=>{
        if(el.trenrast!=el.maxrast){
        this.arrayZaFor[el.pozicija-1]=1;
        }
        else{
          this.arrayZaFor[el.pozicija-1]=2;
        }
      });
    });
  }


  select(i:number){
    this.selectedIndex=i;
    let found=false;
    this.zasSadnice.forEach((el)=>{
      if((el.pozicija-1)==i) {found=true; this.selectedSadnica=el;}
    });
    if(found==false) this.selectedSadnica=null;
  }

  posadi(){
    if(this.selectedMagSadnica!=null && this.zabranjenoSadjenje.indexOf(this.selectedIndex)==-1){
      this.api.posadiSadnicu(this.User,this.Pass,this.selectedMagSadnica,this.trenutniRasadnik.naziv,this.selectedIndex+1).subscribe(data=>{
        this.refreshujSve();
        //alert(data);
        this.selectedSadnica=null;
        this.selectedIndex=null;
      });
    }
  }



  ukloni(){
    if(this.selectedIndex!=null){
      this.api.ukloniZasSadnicu(this.User,this.Pass,this.trenutniRasadnik.naziv,this.selectedIndex+1).subscribe(data=>{
        this.refreshujSve();
        //alert(data);
        this.zabranjenoSadjenje.push(this.selectedIndex);
        var fun = setTimeout((ind)=>{
          this.zabranjenoSadjenje.splice((this.zabranjenoSadjenje.indexOf(ind)),1);
        },60000,this.selectedIndex);
        this.selectedSadnica=null;
        this.selectedIndex=null;
         });
    }
  }

  iskoristiPreparat(){
    if(this.selectedIndex!=null && this.selectedMagPreparat!=null){
      this.api.iskoristiPreparat(this.User,this.Pass,this.selectedMagPreparat,this.trenutniRasadnik.naziv,this.selectedIndex+1).subscribe(data=>{
        this.refreshujSve();
        //alert(data);
        this.selectedSadnica=null;
        this.selectedIndex=null;
      });
    }
  }

  ostaleMagSadnice():Sadnica[]{
    let  ret:Sadnica[]=[];
    if(this.selectedMagSadnica!=null){
    this.magSadnice.forEach((el)=>{
      if((el.naziv!=this.selectedMagSadnica.naziv || el.pred!=this.selectedMagSadnica.pred)){
        if(this.koristiFilter==true && (this.naziv=="" || el.naziv.includes(this.naziv)) && (this.proiz=="" || el.pred.includes(this.proiz) &&
        (this.kol=="" || el.kolicina.toString().includes(this.kol)) && (this.par=="" || el.maxrast.toString().includes(this.par)))) ret.push(el);

        else if (this.koristiFilter==false){ret.push(el);}
      }
      });
     if(this.sort==1 && this.sortType==0){return ret.sort((a, b) => a.naziv.localeCompare(b.naziv));}
     if(this.sort==2 && this.sortType==0){return ret.sort((a, b) => a.pred.localeCompare(b.pred));}
     if(this.sort==3 && this.sortType==0){return ret.sort((a, b) => a.kolicina - b.kolicina);}
     if(this.sort==4 && this.sortType==0){return ret.sort((a, b) => a.maxrast - b.maxrast);}
     if(this.sort==1 && this.sortType==1){return ret.sort((a, b) => b.naziv.localeCompare(a.naziv));}
     if(this.sort==2 && this.sortType==1){return ret.sort((a, b) => b.pred.localeCompare(a.pred));}
     if(this.sort==3 && this.sortType==1){return ret.sort((a, b) => b.kolicina - a.kolicina);}
     if(this.sort==4 && this.sortType==1){return ret.sort((a, b) => b.maxrast - a.maxrast);}
     else{return ret;}
    }
    else{
      this.magSadnice.forEach((el)=>{
          if(this.koristiFilter==true && (this.naziv=="" || el.naziv.includes(this.naziv)) && (this.proiz=="" || el.pred.includes(this.proiz) &&
          (this.kol=="" || el.kolicina.toString().includes(this.kol)) && (this.par=="" || el.maxrast.toString().includes(this.par)))) ret.push(el);
          else if (this.koristiFilter==false){ret.push(el);}
        });
    if(this.sort==1 && this.sortType==0){return ret.sort((a, b) => a.naziv.localeCompare(b.naziv));}
     if(this.sort==2 && this.sortType==0){return ret.sort((a, b) => a.pred.localeCompare(b.pred));}
     if(this.sort==3 && this.sortType==0){return ret.sort((a, b) => a.kolicina - b.kolicina);}
     if(this.sort==4 && this.sortType==0){return ret.sort((a, b) => a.maxrast - b.maxrast);}
     if(this.sort==1 && this.sortType==1){return ret.sort((a, b) => b.naziv.localeCompare(a.naziv));}
     if(this.sort==2 && this.sortType==1){return ret.sort((a, b) => b.pred.localeCompare(a.pred));}
     if(this.sort==3 && this.sortType==1){return ret.sort((a, b) => b.kolicina - a.kolicina);}
     if(this.sort==4 && this.sortType==1){return ret.sort((a, b) => b.maxrast - a.maxrast);}
     else{return ret;}
    }
   }

   selektovanaSadnica():Sadnica[]{
     let ret:Sadnica[]=[];
     if(this.selectedMagSadnica!=null){ret.push(this.selectedMagSadnica); return ret;}
     else return [];
   }

   ostaliMagPreparati():Preparat[]{
    let  ret:Preparat[]=[];
    if(this.selectedMagPreparat!=null){
    this.magPreparati.forEach((el)=>{
      if((el.naziv!=this.selectedMagPreparat.naziv || el.pred!=this.selectedMagPreparat.pred)){
        if(this.koristiFilter==true && (this.naziv=="" || el.naziv.includes(this.naziv)) && (this.proiz=="" || el.pred.includes(this.proiz) &&
        (this.kol=="" || el.kolicina.toString().includes(this.kol)) && (this.par=="" || el.ubrzavanje.toString().includes(this.par)))) ret.push(el);
        else if (this.koristiFilter==false){ret.push(el);}
      }
      });
      if(this.sort==1 && this.sortType==0){return ret.sort((a, b) => a.naziv.localeCompare(b.naziv));}
      if(this.sort==2 && this.sortType==0){return ret.sort((a, b) => a.pred.localeCompare(b.pred));}
      if(this.sort==3 && this.sortType==0){return ret.sort((a, b) => a.kolicina - b.kolicina);}
      if(this.sort==4 && this.sortType==0){return ret.sort((a, b) => a.ubrzavanje - b.ubrzavanje);}
      if(this.sort==1 && this.sortType==1){return ret.sort((a, b) => b.naziv.localeCompare(a.naziv));}
      if(this.sort==2 && this.sortType==1){return ret.sort((a, b) => b.pred.localeCompare(a.pred));}
      if(this.sort==3 && this.sortType==1){return ret.sort((a, b) => b.kolicina - a.kolicina);}
      if(this.sort==4 && this.sortType==1){return ret.sort((a, b) => b.ubrzavanje - a.ubrzavanje);}
      else{return ret;}
    }
    else{
      this.magPreparati.forEach((el)=>{
          if(this.koristiFilter==true && (this.naziv=="" || el.naziv.includes(this.naziv)) && (this.proiz=="" || el.pred.includes(this.proiz) &&
          (this.kol=="" || el.kolicina.toString().includes(this.kol)) && (this.par=="" || el.ubrzavanje.toString().includes(this.par)))) ret.push(el);
          else if (this.koristiFilter==false){ret.push(el);}
        });
        if(this.sort==1 && this.sortType==0){return ret.sort((a, b) => a.naziv.localeCompare(b.naziv));}
        if(this.sort==2 && this.sortType==0){return ret.sort((a, b) => a.pred.localeCompare(b.pred));}
        if(this.sort==3 && this.sortType==0){return ret.sort((a, b) => a.kolicina - b.kolicina);}
        if(this.sort==4 && this.sortType==0){return ret.sort((a, b) => a.ubrzavanje - b.ubrzavanje);}
        if(this.sort==1 && this.sortType==1){return ret.sort((a, b) => b.naziv.localeCompare(a.naziv));}
        if(this.sort==2 && this.sortType==1){return ret.sort((a, b) => b.pred.localeCompare(a.pred));}
        if(this.sort==3 && this.sortType==1){return ret.sort((a, b) => b.kolicina - a.kolicina);}
        if(this.sort==4 && this.sortType==1){return ret.sort((a, b) => b.ubrzavanje - a.ubrzavanje);}
        else{return ret;}
    }
   }

   selektovaniPreparat():Preparat[]{
     let ret:Preparat[]=[];
     if(this.selectedMagPreparat!=null){ret.push(this.selectedMagPreparat); return ret;}
     else return [];
   }

   updateSelMagSad(){
     if(this.selectedMagSadnica!=null){
      let found=false;
      this.magSadnice.forEach((sad)=>{
        if(sad.naziv==this.selectedMagSadnica.naziv && sad.pred==this.selectedMagSadnica.pred) {this.selectedMagSadnica.kolicina=sad.kolicina; found=true;}
      });
      if(found==false) this.selectedMagSadnica=null;
     }
   }

   updateSelMagPrep(){
    if(this.selectedMagPreparat!=null){
      let found=false;
     this.magPreparati.forEach((prep)=>{
       if(prep.naziv==this.selectedMagPreparat.naziv && prep.pred==this.selectedMagPreparat.pred) {this.selectedMagPreparat.kolicina=prep.kolicina;  found=true;}
     });
     if(found==false) this.selectedMagPreparat=null;
    }
  }


}
