import { ApiService } from './../../api.service';
import { Preparat } from './../models/preparat';
import { Sadnica } from './../models/sadnica';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Komentar } from '../models/komentar';

@Component({
  selector: 'app-proizvod',
  templateUrl: './proizvod.component.html',
  styleUrls: ['./proizvod.component.css']
})
export class ProizvodComponent implements OnInit {

  sadnica:Sadnica;
  preparat:Preparat;
  komentari:Komentar[]=[];

  ocenaSadnice:number=0;
  ocenaPreparata:number=0;
  tip:number=0;

  User:string;
  Pass:string;


  ocena:number=5;
  tekst:string="";
  resMessage:string="";

  constructor(private router:Router,private api:ApiService) { }

  ngOnInit(): void {
    if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
      if(JSON.parse(localStorage.getItem("SadnicaP"))!=null){
        this.sadnica = JSON.parse(localStorage.getItem("SadnicaP"));
        this.tip=2;
        this.dohvatiOcenuSadniceP();
        this.dohvatiKomentareSadnicaP();
      }
      else if (JSON.parse(localStorage.getItem("SadnicaPP"))!=null){
        this.sadnica = JSON.parse(localStorage.getItem("SadnicaPP"));
        this.tip=1;
        this.dohvatiOcenuSadnicePP();
        this.dohvatiKomentareSadnicaPP();
      }
      else if (JSON.parse(localStorage.getItem("PreparatP"))!=null){
        this.preparat = JSON.parse(localStorage.getItem("PreparatP"));
        this.tip=2;
        this.dohvatiOcenuPreparataP();
        this.dohvatiKomentarePreparataP();
      }
      else if (JSON.parse(localStorage.getItem("PreparatPP"))!=null){
        this.preparat = JSON.parse(localStorage.getItem("PreparatPP"));
        this.tip=1;
        this.dohvatiOcenuPreparataPP();
        this.dohvatiKomentarePreparataPP();
      }
    }
  }

  povratak(){
    var povratak=localStorage.getItem("ret");
    if(povratak==null){
      localStorage.setItem("User",null);
      localStorage.setItem("Pass",null);
      this.router.navigate(['/login']);
    }
    else{
      this.router.navigate([povratak]);
    }
  }

  promenaLozinke():void{
    localStorage.setItem("returnPage","/proizvod");
    this.router.navigate(['/promenalozinke']);
  }

  odjava():void{
    localStorage.setItem("User",null);
    localStorage.setItem("Pass",null);
    this.router.navigate(['/login']);
  }

  dohvatiOcenuSadnicePP():void{
    this.api.dohvatiOcenuSadnicePP(this.User,this.Pass,this.sadnica.naziv,this.sadnica.pred).subscribe(data=>{
      this.ocenaSadnice=data;
    });
  }

  dohvatiOcenuSadniceP():void{
    this.api.dohvatiOcenuSadniceP(this.User,this.Pass,this.sadnica.naziv,this.sadnica.pred).subscribe(data=>{
      this.ocenaSadnice=data;
    });
  }

  dohvatiOcenuPreparataPP():void{
    this.api.dohvatiOcenuPreparataPP(this.User,this.Pass,this.preparat.naziv,this.preparat.pred).subscribe(data=>{
      this.ocenaPreparata=data;
    })
  }

  dohvatiOcenuPreparataP():void{
    this.api.dohvatiOcenuPreparataP(this.User,this.Pass,this.preparat.naziv,this.preparat.pred).subscribe(data=>{
      this.ocenaPreparata=data;
    })
  }

  dohvatiKomentarePreparataP():void{
    this.api.dohvatiKomentarePreparataP(this.User,this.Pass,this.preparat.naziv,this.preparat.pred).subscribe(data=>
      this.komentari=data);
  }

  dohvatiKomentarePreparataPP():void{
    this.api.dohvatiKomentarePreparataPP(this.User,this.Pass,this.preparat.naziv,this.preparat.pred).subscribe(data=>
      this.komentari=data);
  }

  dohvatiKomentareSadnicaP():void{
    this.api.dohvatiKomentareSadnicaP(this.User,this.Pass,this.sadnica.naziv,this.sadnica.pred).subscribe(data=>
      this.komentari=data);
  }

  dohvatiKomentareSadnicaPP():void{
    this.api.dohvatiKomentareSadnicaPP(this.User,this.Pass,this.sadnica.naziv,this.sadnica.pred).subscribe(data=>
      this.komentari=data);
  }

  posaljiKomentarSad():void{
    this.api.dodajKomentarSadnica(this.User,this.Pass,this.sadnica.naziv,this.sadnica.pred,this.tekst,this.ocena).subscribe(data=>{this.resMessage=data;
      if(this.tip==1) this.dohvatiKomentareSadnicaPP();
      else if (this.tip==2) this.dohvatiKomentareSadnicaP();
    });
  }

  posaljiKomentarPrep():void{
    this.api.dodajKomentarPreparat(this.User,this.Pass,this.preparat.naziv,this.preparat.pred,this.tekst,this.ocena).subscribe(data=>{
      this.resMessage=data;
      if(this.tip==1) this.dohvatiKomentarePreparataPP();
      else if (this.tip==2) this.dohvatiKomentarePreparataP();
    });
  }

}
