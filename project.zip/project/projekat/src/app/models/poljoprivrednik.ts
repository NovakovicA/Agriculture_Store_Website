export class Poljoprivrednik{
ime:string;
prezime:string;
korime:string;
lozinka:string;
datum:Date;
mesto:string;
email:string;
telefon:string;
}
