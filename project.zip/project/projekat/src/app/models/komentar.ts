export class Komentar{
  naziv:string;
  sadrzaj:string;
  ocena:number;
  poljoprivrednik:string;
  pred:string;
  tip:string;
}
