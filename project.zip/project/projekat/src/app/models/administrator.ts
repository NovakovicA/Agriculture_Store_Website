export class Administrator{
  korime:string;
  lozinka:string;
  }
