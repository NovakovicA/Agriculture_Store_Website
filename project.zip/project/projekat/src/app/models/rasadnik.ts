export class Rasadnik{
  naziv:string;
  mesto:string;
  brzas:number;
  bruk:number;
  voda:number;
  temp:string;
  }
