export class Preparat{
  naziv:string;
  pred:string;
  cena:Number;
  kolicina:number;
  ubrzavanje:number;
  }
