export class Narudzbina{
id:Number;
poljoprivrednik:string;
rasadnik:string;
pred:string;
status:string;
datum:Date;
}
