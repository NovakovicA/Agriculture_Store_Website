export class Sadnica{
  naziv:string;
  pred:string;
  cena:Number;
  kolicina:number;
  pozicija:number;
  trenrast:number;
  maxrast:number;
  }
