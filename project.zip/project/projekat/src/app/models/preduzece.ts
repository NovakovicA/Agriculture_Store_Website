export class Preduzece{
naziv:string;
korime:string;
lozinka:string;
datum:Date;
mesto:string;
email:string;
}
