import { RouterModule, Router } from '@angular/router';
import { ApiService } from './../../api.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private api:ApiService,private router:Router) { }

  User: string;
  Pass: string;
  message: string;
  messageType:number=0;

  ngOnInit(): void {
  }


  prijava():void{
    this.api.login(this.User,this.Pass).subscribe(data=>{
      this.message=data.replace(/"/g,"");
      this.messageType=1;
      localStorage.setItem("User",this.User);
      localStorage.setItem("Pass",this.Pass);
      if(this.message.startsWith("Admin")){
        this.messageType=0;
      setTimeout(() => {
        this.router.navigate(["/admin"]);
    }, 2000);}
    else if(this.message.startsWith("Poljoprivrednik")){
      this.messageType=0;
      setTimeout(() => {
        this.router.navigate(["/poljoprivrednik"]);
    }, 2000);}
    else if(this.message.startsWith("Preduzece")){
      this.messageType=0;
      setTimeout(() => {
        this.router.navigate(["/preduzece"]);
    }, 2000);}
      this.User="";
      this.Pass="";
    });
  }


}
