import { ApiService } from './../../api.service';
import { Poljoprivrednik } from './../models/poljoprivrednik';
import { Component, OnInit } from '@angular/core';
import { Preduzece } from '../models/preduzece';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  constructor(private api:ApiService) { }

  ngOnInit(): void {
  }

  regtype:string="1";
  message:string;
  messageType:number=1;

  preduzeceTemp: Preduzece=new Preduzece;
  poljoprivrednikTemp: Poljoprivrednik=new Poljoprivrednik;

  lozinkap1:string;
  lozinkap2:string;

  captcha1:boolean=true;
  captcha2:boolean=true;


  solved_captcha1():void{
    this.captcha1=true;
  }

  solved_captcha2():void{
    this.captcha2=true;
  }

  registrujPoljoprivrednika():void{
    let regexZaLozinku = /^([a-z](?=.*[!@#$%^&*])(?=.*\d)(?=.*[A-Z]).{6,})|[A-Z](?=.*[!@#$%^&*])(?=.*\d).{6,}$/;
    let regexZaEmail = /^\w+@\w+\.\w+$/;
    if((this.poljoprivrednikTemp.ime==null) || (this.poljoprivrednikTemp.prezime==null) || (this.poljoprivrednikTemp.korime==null)
    || (this.poljoprivrednikTemp.lozinka==null)|| (this.poljoprivrednikTemp.datum==null)|| (this.poljoprivrednikTemp.mesto==null)
    || (this.poljoprivrednikTemp.email==null)|| (this.poljoprivrednikTemp.telefon==null)){
      this.messageType=1;
      this.message="Greska: popunite sva polja!";
      return;
    }
    else if (this.poljoprivrednikTemp.lozinka!=this.lozinkap1){
      this.messageType=1;
      this.message="Greska: lozinke se ne poklapaju!";
      return;
    }
    else if(!this.captcha1){
      this.messageType=1;
      this.message="Greska: captcha nije resena!";
      return;
    }
    else if (!regexZaLozinku.test(this.poljoprivrednikTemp.lozinka)){
      this.messageType=1;
      this.message="Greska: lozinka u pogresnom formatu!";
      return;
    }
    else if (!regexZaEmail.test(this.poljoprivrednikTemp.email)){
      this.messageType=1;
      this.message="Greska: email u pogresnom formatu!";
      return;
    }
    else{
      this.api.registrujPoljoprivrednika(this.poljoprivrednikTemp).subscribe(data=>
        {
          this.message=JSON.stringify(data).replace(/"/g,"");
          if(this.message.startsWith("Vas")){
            this.messageType=0;
          }
          else{
            this.messageType=1;
          }
        });
    }
  }



  registrujPreduzece():void{
    let regexZaLozinku = /^([a-z](?=.*[!@#$%^&*])(?=.*\d)(?=.*[A-Z]).{6,})|[A-Z](?=.*[!@#$%^&*])(?=.*\d).{6,}$/;
    let regexZaEmail = /^\w+@\w+\.\w+$/;
    if((this.preduzeceTemp.naziv==null) || (this.preduzeceTemp.korime==null) || (this.preduzeceTemp.lozinka==null)
    || (this.preduzeceTemp.datum==null)|| (this.preduzeceTemp.mesto==null)|| (this.preduzeceTemp.email==null))
    {
      this.messageType=1;
      this.message="Greska: popunite sva polja!";
      return;
    }
    else if (this.preduzeceTemp.lozinka!=this.lozinkap2){
      this.messageType=1;
      this.message="Greska: lozinke se ne poklapaju!";
      return;
    }
    else if(this.captcha2=false){
      this.messageType=1;
      this.message="Greska: captcha nije resena!";
      return;
    }
    else if (!regexZaLozinku.test(this.preduzeceTemp.lozinka)){
      this.messageType=1;
      this.message="Greska: lozinka u pogresnom formatu!";
      return;
    }
    else if (!regexZaEmail.test(this.preduzeceTemp.email)){
      this.messageType=1;
      this.message="Greska: email u pogresnom formatu!";
      return;
    }
    else{
      this.api.registrujPreduzece(this.preduzeceTemp).subscribe(data=>
        {
          this.message=JSON.stringify(data).replace(/"/g,"");
          if(this.message.startsWith("Vas")){
            this.messageType=0;
          }
          else{
            this.messageType=1;
          }
        });
    }
  }



}
