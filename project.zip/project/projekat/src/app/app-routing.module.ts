import { ProdavnicaComponent } from './prodavnica/prodavnica.component';
import { RasadnikComponent } from './rasadnik/rasadnik.component';
import { PromenalozinkeComponent } from './promenalozinke/promenalozinke.component';
import { PreduzeceComponent } from './preduzece/preduzece.component';
import { Preduzece } from './models/preduzece';
import { PoljoprivrednikComponent } from './poljoprivrednik/poljoprivrednik.component';
import { AdminComponent } from './admin/admin.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProizvodComponent } from './proizvod/proizvod.component';


const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path: 'reg',component: RegistrationComponent},
  {path: 'admin',component:AdminComponent},
  {path:  'poljoprivrednik',component:PoljoprivrednikComponent},
  {path:  'preduzece', component:PreduzeceComponent},
  {path:   'promenalozinke',component:PromenalozinkeComponent},
  {path:   'rasadnik',component:RasadnikComponent},
  {path:   'prodavnica',component:ProdavnicaComponent},
  {path:   'proizvod',component:ProizvodComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
