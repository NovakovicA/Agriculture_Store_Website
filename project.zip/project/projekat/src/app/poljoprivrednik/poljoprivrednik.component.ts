import { ApiService } from './../../api.service';
import { Rasadnik } from './../models/rasadnik';
import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-poljoprivrednik',
  templateUrl: './poljoprivrednik.component.html',
  styleUrls: ['./poljoprivrednik.component.css']
})
export class PoljoprivrednikComponent implements OnInit {
  welcomeMessage:string;
  resMessage:string;
  warningMessage:string[]=[];
  User:string;
  Pass:string;
  refresh;

  rasadnici:Rasadnik[]=[];
  ras:Rasadnik=new Rasadnik;
  duzina:number;
  sirina:number;

  constructor(private router:Router,private api:ApiService) {
   this.refresh = setInterval(()=> { this.dohvatiRasadnike() }, 5000);
  }

  ngOnInit(): void {
     if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
      this.welcomeMessage="Dobrodosli, ulogovani ste kao poljoprivrednik " + this.User + ".";
    }
    this.dohvatiRasadnike();
  }

  ngOnDestroy() {
    clearInterval(this.refresh);
  }

  odjava():void{
    localStorage.setItem("User",null);
    localStorage.setItem("Pass",null);
    this.router.navigate(['/login']);
  }

  promenaLozinke():void{
    localStorage.setItem("returnPage","/poljoprivrednik");
    this.router.navigate(['/promenalozinke']);
  }

  dohvatiRasadnike():void{
   var rasadnicitemp:Rasadnik[]=[];
    this.api.dohvatiRasadnike(this.User, this.Pass).subscribe(data=>{
      rasadnicitemp=data;
      this.rasadnici=rasadnicitemp;
      this.warningMessage=[]
      this.rasadnici.forEach(ras=>{
        if((parseFloat(ras.temp)<12) || (ras.voda<75)){
          this.warningMessage.push("Rasadnik " + ras.naziv + " zahteva odrzavanje!");
        }
      });
    });
  }

  dodajRasadnik():void{
    if(this.duzina<=0 || this.sirina<=0 || this.sirina==null || this.duzina==0){this.resMessage="Sirina i duzina ne smeju biti manji ili jednaki 0.";return;}
    this.ras.bruk=this.duzina * this.sirina;
    this.api.dodajRasadnik(this.User,this.Pass,this.ras).subscribe(data=>{this.resMessage=data;this.dohvatiRasadnike();});
  }

  otvoriRasadnik(ras:Rasadnik){
    localStorage.setItem("trenutniRasadnik",JSON.stringify(ras));
    this.router.navigate(["/rasadnik"]);
  }

  prodavnica():void{
    this.router.navigate(['/prodavnica']);
  }


}
