import { ApiService } from './../../api.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promenalozinke',
  templateUrl: './promenalozinke.component.html',
  styleUrls: ['./promenalozinke.component.css']
})
export class PromenalozinkeComponent implements OnInit {


  message:string;
  User:string;
  Pass:string;
  newPass:string;
  newPass2:string;
  messageType:number=0;

  constructor(private router:Router,private api:ApiService) { }



  ngOnInit(): void {
  }

  povratakNaGlavnu():void{
    var povratak=localStorage.getItem("returnPage");
    if(povratak==null){
      localStorage.setItem("User",null);
      localStorage.setItem("Pass",null);
      this.router.navigate(['/login']);
    }
    else{
      this.router.navigate([povratak]);
    }
  }

  odjava():void{
    localStorage.setItem("User",null);
    localStorage.setItem("Pass",null);
    this.router.navigate(['/login']);
  }

  promeniLozinku(){
    let regexZaLozinku = /^([a-z](?=.*[!@#$%^&*])(?=.*\d)(?=.*[A-Z]).{6,})|[A-Z](?=.*[!@#$%^&*])(?=.*\d).{6,}$/;
    if((this.newPass==this.newPass2) && regexZaLozinku.test(this.newPass) && !(this.newPass==this.Pass)){
    this.api.promenaLozinke(this.User,this.Pass,this.newPass).subscribe(data=>{
      this.message=JSON.stringify(data).replace(/"/g,"");
      if(this.message.startsWith("Uspesno")){
        this.messageType=0;
        setTimeout(() => {
          this.odjava();
        },5000);
      }
      else{
        this.messageType=1;
      }
    });
  }
  else if(!(this.newPass==this.newPass2)){
   this.messageType=1;
   this.message="Popunite oba polja za lozinku."
  }
  else if((this.newPass==this.Pass)){
    this.messageType=1;
    this.message="Nova lozinka ne sme da bude ista kao stara."
   }
  else {
    this.messageType=1;
    this.message="Lozinka nije u dobrom formatu."
   }
  }

}
