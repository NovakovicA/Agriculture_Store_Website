import { Administrator } from './../models/administrator';
import { Preduzece } from './../models/preduzece';
import { Poljoprivrednik } from './../models/poljoprivrednik';
import { ApiService } from './../../api.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

welcomeMessage:string;
User:string;
Pass:string;
refresh;

administratori:Administrator[]=[];
poljoprivrednici:Poljoprivrednik[]=[];
preduzeca:Preduzece[]=[];
zahpoljoprivrednika:Poljoprivrednik[]=[];
zahpreduzeca:Preduzece[]=[];

administratoriTemp:Administrator[]=[];
poljoprivredniciTemp:Poljoprivrednik[]=[];
preduzecaTemp:Preduzece[]=[];
zahpoljoprivrednikaTemp:Poljoprivrednik[]=[];
zahpreduzecaTemp:Preduzece[]=[];

tipForme:number=0;
tipMod:number=0;
admin:Administrator=new Administrator;
polj:Poljoprivrednik=new Poljoprivrednik;
pred:Preduzece=new Preduzece;
resMessage:string="";

  constructor(private router:Router,private api:ApiService) {
   this.refresh = setInterval(()=> { this.refreshujPodatke() }, 5000);
  }



  ngOnInit(): void {
    if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
      this.welcomeMessage="Dobrodosli, ulogovani ste kao administrator " + this.User + ".";
    }
    this.refreshujPodatke();
  }

  ngOnDestroy() {
    clearInterval(this.refresh);
  }

  odjava():void{
    localStorage.setItem("User",null);
    localStorage.setItem("Pass",null);
    this.router.navigate(['/login']);
  }

  promenaLozinke():void{
    localStorage.setItem("returnPage","/admin");
    this.router.navigate(['/promenalozinke']);
  }

  refreshujPodatke():void{
    this.administratoriTemp=[];
    this.poljoprivredniciTemp=[];
    this.preduzecaTemp=[];
    this.zahpoljoprivrednikaTemp=[];
    this.zahpreduzecaTemp=[];
    this.api.dohvatiAdmine(this.User,this.Pass).subscribe(data=>{
      this.administratoriTemp=data;
      this.administratori=this.administratoriTemp;
    });
    this.api.dohvatiPoljoprivrednike(this.User,this.Pass).subscribe(data=>{
      this.poljoprivredniciTemp=data;
      this.poljoprivrednici=this.poljoprivredniciTemp;
    });
    this.api.dohvatiPreduzeca(this.User,this.Pass).subscribe(data=>{
      this.preduzecaTemp=data;
      this.preduzeca=this.preduzecaTemp;
    });
    this.api.dohvatiZahPreduzeca(this.User,this.Pass).subscribe(data=>{
      this.zahpreduzecaTemp=data;
      this.zahpreduzeca= this.zahpreduzecaTemp;
    });
    this.api.dohvatiZahPoljoprivrednika(this.User,this.Pass).subscribe(data=>{
      this.zahpoljoprivrednikaTemp=data;
      this.zahpoljoprivrednika=this.zahpoljoprivrednikaTemp;
    });
  }

  modifikujA(admin:Administrator):void{
    this.api.modifikujAdmina(admin,this.User,this.Pass).subscribe(data=>{
      this.resMessage=data.replace(/"/g,"");
      this.refreshujPodatke();
    });
  }


  modifikujPP(polj:Poljoprivrednik):void{
    this.api.modifikujPoljoprivrednika(polj,this.User,this.Pass).subscribe(data=>{
      this.resMessage=data.replace(/"/g,"");
      this.refreshujPodatke();
    });
  }

  modifikujP(pred:Preduzece):void{
    this.api.modifikujPreduzece(pred,this.User,this.Pass).subscribe(data=>{
      this.resMessage=data.replace(/"/g,"");
      this.refreshujPodatke();
    });
  }


  obrisiA(admin:Administrator):void{
    this.api.obrisiAdmina(this.User,this.Pass,admin.korime).subscribe(data=>{this.refreshujPodatke();});
  }

  obrisiPP(polj:Poljoprivrednik):void{
    this.api.obrisiPoljoprivrednika(this.User,this.Pass,polj.korime).subscribe(data=>{this.refreshujPodatke();});
  }



  obrisiP(pred:Preduzece):void{
    this.api.obrisiPreduzece(this.User,this.Pass,pred.korime).subscribe(data=>{this.refreshujPodatke();});
  }

  prihvatiP(pred:Preduzece):void{
    this.api.obrisiZahtevPreduzeca(this.User,this.Pass,pred.korime).subscribe(data=>{});
    this.api.dodajPreduzece(pred,this.User,this.Pass).subscribe(data=>{this.refreshujPodatke();});
  }

  prihvatiPP(polj:Poljoprivrednik):void{
    this.api.obrisiZahtevPoljoprivrednika(this.User,this.Pass,polj.korime).subscribe(data=>{});
    this.api.dodajPoljoprivrednika(polj,this.User,this.Pass).subscribe(data=>{this.refreshujPodatke();});
  }

  odbijP(pred:Preduzece):void{
    this.api.obrisiZahtevPreduzeca(this.User,this.Pass,pred.korime).subscribe(data=>{this.refreshujPodatke();});
  }

  odbijPP(polj:Poljoprivrednik):void{
    this.api.obrisiZahtevPoljoprivrednika(this.User,this.Pass,polj.korime).subscribe(data=>{this.refreshujPodatke();});
  }

  dodajA():void{
    this.api.dodajAdmina(this.admin,this.User,this.Pass).subscribe(data=>{
    this.resMessage=data.replace(/"/g,"");
    this.refreshujPodatke();
  });
  }

  dodajP():void{
    this.api.dodajPreduzece(this.pred,this.User,this.Pass).subscribe(data=>{
    this.resMessage=data.replace(/"/g,"");
    this.refreshujPodatke();
    });
  }

  dodajPP():void{
    this.api.dodajPoljoprivrednika(this.polj,this.User,this.Pass).subscribe(data=>{
    this.resMessage=data.replace(/"/g,"");
    this.refreshujPodatke();
    });
  }

  resetA(){
    this.admin=new Administrator;
  }

  resetP(){
    this.pred=new Preduzece;
  }

  resetPP(){
    this.polj=new Poljoprivrednik;
  }

}
