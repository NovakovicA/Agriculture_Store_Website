import { Narudzbina } from './../models/narudzbina';
import { ApiService } from './../../api.service';
import { Preparat } from './../models/preparat';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Sadnica } from '../models/sadnica';

@Component({
  selector: 'app-preduzece',
  templateUrl: './preduzece.component.html',
  styleUrls: ['./preduzece.component.css']
})
export class PreduzeceComponent implements OnInit {

  welcomeMessage:string;
  User:string;
  Pass:string;
  sadnice:Sadnica[]=[];
  preparati:Preparat[]=[];
  narudzbine:Narudzbina[]=[];

  narudzbinePoDanima:number[]=[];

  barChartOptions={
    scaleShowVerticalLines:false,
    responsive:true
  };
  barChartLabels=["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"];
  barChartLegend=true;
  barChartType="bar";
  barChartData=[
    {data:this.narudzbinePoDanima, label:"Broj narudzbina"}
  ];

  sortNar:boolean=false;

  proizvodi:string="";

  refresh;
  mod:number=0;
  dodaj:number=0;
  tempSadnica=new Sadnica;  //za dodavanje
  tempPreparat = new Preparat;  //za dodavanje
  responseMessage:string;

  constructor(private router:Router,private api:ApiService) { this.refresh = setInterval(()=> { this.dohvatiSve() }, 5000);}

  ngOnInit(): void {
     if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
      this.welcomeMessage="Dobrodosli, ulogovani ste kao preduzece " + this.User + ".";
      this.dohvatiSve();
    }
  }

  ngOnDestroy() {
    clearInterval(this.refresh);
  }

  odjava():void{
    localStorage.setItem("User",null);
    localStorage.setItem("Pass",null);
    this.router.navigate(['/login']);
  }

  promenaLozinke():void{
    localStorage.setItem("returnPage","/preduzece");
    this.router.navigate(['/promenalozinke']);
  }

  dohvatiSve():void{
    this.api.dohvatiSadnice(this.User,this.Pass).subscribe(data=>this.sadnice=data);
    this.api.dohvatiPreparate(this.User,this.Pass).subscribe(data=>this.preparati=data);
    this.api.dohvatiNarudzbine(this.User,this.Pass).subscribe(data=>{this.narudzbine=data});
    this.api.dohvatiSveNarudzbine(this.User,this.Pass).subscribe(data=>{
      let tempArray:number[]=[]; let trVreme=new Date();
      for(let i=0;i<31;i++){tempArray.push(0);}
      data.forEach((el)=>{
        let vrNar=el.datum;
        let brDana=Math.round((new Date(trVreme).getTime()-new Date(vrNar).getTime())/ (1000 * 3600 * 24));
        if(brDana>=0 && brDana<=30){
          tempArray[brDana]++;
        }
      });
      this.narudzbinePoDanima=tempArray;
      this.barChartData=[{data:this.narudzbinePoDanima, label:"Broj narudzbina"}];
    });
  }

  ukloniSadnicu(sad:Sadnica):void{
    this.api.ukloniSadnicu(this.User,this.Pass,sad).subscribe(data=>{this.dohvatiSve();});
  }

  ukloniPreparat(prep:Preparat):void{
    this.api.ukloniPreparat(this.User,this.Pass,prep).subscribe(data=>{this.dohvatiSve();});
  }

  resetS():void{
    this.tempSadnica=new Sadnica;
  }

  resetP():void{
    this.tempPreparat=new Preparat;
  }


  dodajSadnicu():void{
    if (this.tempSadnica.kolicina>0 && this.tempSadnica.maxrast>0 && this.tempSadnica.cena>0){
    this.api.dodajSadnicu(this.User,this.Pass,this.tempSadnica).subscribe(data=>{this.responseMessage=data; this.dohvatiSve();});}
  }

  dodajPreparat():void{
    if(this.tempPreparat.cena>0 && this.tempPreparat.kolicina>0 && this.tempPreparat.ubrzavanje>0){
    this.api.dodajPreparat(this.User,this.Pass,this.tempPreparat).subscribe(data=>{this.responseMessage=data;this.dohvatiSve();});}
  }

  modifikujSadnicu(){
    this.api.modifikujSadnicu(this.User,this.Pass,this.tempSadnica).subscribe(data=>{this.responseMessage=data;this.dohvatiSve();})
  }

  modifikujPreparat():void{
    this.api.modifikujPreparat(this.User,this.Pass,this.tempPreparat).subscribe(data=>{this.responseMessage=data;this.dohvatiSve();});
  }


  sortiraj():void{
    if(this.sortNar==false){
      this.sortNar=true;
    }
    else{
      this.sortNar=false;
    }
  }

  sortRastuce():Narudzbina[]{
    return  this.narudzbine.sort((a, b) => new Date(b.datum).getTime() - new Date(a.datum).getTime());
  }

  sortOpadajuce():Narudzbina[]{
    return   this.narudzbine.sort((a, b) => new Date(a.datum).getTime() - new Date(b.datum).getTime());
  }

  ispisiProizvode(id:Number):void{
    this.proizvodi="Proizvodi: ";
     this.api.dohvatiNarSadnice(this.User,this.Pass,id).subscribe(data=>{
       data.forEach((el)=>{this.proizvodi+= "(Naziv: " + el.naziv + ", proizvodjac: " + el.pred +  ", kolicina: " + el.kolicina + ") "});
     });
     this.api.dohvatiNarPreparate(this.User,this.Pass,id).subscribe(data=>{
      data.forEach((el)=>{this.proizvodi+= "(Naziv: " + el.naziv + ", proizvodjac: " + el.pred +  ", kolicina: " + el.kolicina + ") "});
       if(this.proizvodi=="Proizvodi: ") {this.proizvodi="Proizvodi: /."}
     });
   }

   izbrisiNarudzbinu(id:Number):void{
    this.api.izbrisiNarudzbinu(this.User,this.Pass,id).subscribe(data=>this.dohvatiSve());
   }

    potvrdiNarudzbinu(id:Number):void{
    this.api.potvrdiNarudzbinu(this.User,this.Pass,id).subscribe(data=>this.dohvatiSve());
   }

   otvoriSadnicu(sad:Sadnica){
    localStorage.setItem("SadnicaPP",null);
    localStorage.setItem("SadnicaP",JSON.stringify(sad));
    localStorage.setItem("PreparatP",null);
    localStorage.setItem("PreparatPP",null);
    localStorage.setItem("ret","/preduzece");
    this.router.navigate(["/proizvod"]);
  }

  otvoriPreparat(prep:Preparat){
    localStorage.setItem("PreparatPP",null);
    localStorage.setItem("SadnicaPP",null);
    localStorage.setItem("SadnicaP",null);
    localStorage.setItem("PreparatP",JSON.stringify(prep));
    localStorage.setItem("ret","/preduzece");
    this.router.navigate(["/proizvod"]);
  }
}
