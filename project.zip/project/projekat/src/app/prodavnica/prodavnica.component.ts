import { Narudzbina } from './../models/narudzbina';
import { Preparat } from './../models/preparat';
import { ApiService } from './../../api.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Sadnica } from '../models/sadnica';

@Component({
  selector: 'app-prodavnica',
  templateUrl: './prodavnica.component.html',
  styleUrls: ['./prodavnica.component.css']
})
export class ProdavnicaComponent implements OnInit {

  constructor(private router:Router,private api:ApiService) { this.refresh=setInterval(()=> { this.dohvatiSve() }, 5000); }

  refresh;
  User:string;
  Pass:string;
  sadnice:Sadnica[]=[];
  preparati:Preparat[]=[];
  narudzbine:Narudzbina[]=[];

  narSadnice:Sadnica[]=[];
  narPreparati:Preparat[]=[];
  narRasadnik:string;
  narId:Number=0;

  responseMessage;
  addMessage;

  tempSadnica:Sadnica=new Sadnica;
  tempPreparat:Preparat=new Preparat;
  dodaj=0;


  ngOnInit(): void {
    if((localStorage.getItem("User")==null) || (localStorage.getItem("Pass")==null)){
      this.router.navigate(['/login']);
    }
    else{
      this.User=localStorage.getItem("User");
      this.Pass=localStorage.getItem("Pass");
      this.dohvatiSve();
    }
  }

  ngOnDestroy() {
    clearInterval(this.refresh);
  }


  promenaLozinke():void{
    localStorage.setItem("returnPage","/poljoprivrednik");
    this.router.navigate(['/promenalozinke']);
  }

  odjava():void{
    localStorage.setItem("User",null);
    localStorage.setItem("Pass",null);
    this.router.navigate(['/login']);
  }

  poljoprivrednik():void{
    this.router.navigate(['/poljoprivrednik']);
  }

  dohvatiSve(){
    this.api.dohvatiProdavaneSadnice(this.User,this.Pass).subscribe(data=>{
      this.sadnice=data;
    });
    this.api.dohvatiProdavaniPreparati(this.User,this.Pass).subscribe(data=>{
      this.preparati=data;
    });
    this.api.dohvatiNarudzbineSeljaka(this.User,this.Pass).subscribe(data=>{
      this.narudzbine=data;
    });
  }

  ukloniNarudzbinu(id:Number):void{
    this.api.ukloniNarudzbinu(this.User,this.Pass,id).subscribe(data=>{
      this.dohvatiSve();
    });
  }


  reset(){
    this.narSadnice=[];
    this.narPreparati=[];
    this.tempPreparat=new Preparat;
    this.tempSadnica=new Sadnica;
    this.addMessage="";
    this.responseMessage="";
    this.narRasadnik="";
  }

  dodajPreparat(p:Preparat){
    if(p.kolicina>this.preparati.find(el=>el.naziv==p.naziv && el.pred==p.pred).kolicina){
      this.addMessage="Nemoguce dodati ovu kolicinu proizvoda u narudzbinu.";
      return;
    }
    else if(this.narPreparati.find(el=>el.pred!=p.pred)!=null){
      this.addMessage="Nemoguce dodati proizvode razlicitih preduzeca u istu porudzbinu.";
      return;
    }
    else if(this.narSadnice.find(el=>el.pred!=p.pred)!=null){
      this.addMessage="Nemoguce dodati proizvode razlicitih preduzeca u istu porudzbinu.";
      return;
    }
    else{
      this.narPreparati.push(p);
      this.addMessage="Uspesno dodat preparat u narudzbinu.";
    }
  }

  dodajSadnicu(s:Sadnica):void{
    if(s.kolicina>this.sadnice.find(el=>el.naziv==s.naziv && el.pred==s.pred).kolicina){
      this.addMessage="Nemoguce dodati ovu kolicinu proizvoda u narudzbinu.";
      return;
    }
    else if(this.narPreparati.find(el=>el.pred!=s.pred)!=null){
      this.addMessage="Nemoguce dodati proizvode razlicitih preduzeca u istu porudzbinu.";
      return;
    }
    else if(this.narSadnice.find(el=>el.pred!=s.pred)!=null){
      this.addMessage="Nemoguce dodati proizvode razlicitih preduzeca u istu porudzbinu.";
      return;
    }
    else{
      this.narSadnice.push(s);
      this.addMessage="Uspesno dodata sadnica u narudzbinu.";
    }
  }

  selectSadnica(s:Sadnica){
    this.tempSadnica=new Sadnica;
    this.tempSadnica=s;
    this.dodaj=0;
  }

  selectPreparat(p:Preparat){
    this.tempPreparat=new Preparat;
    this.tempPreparat=p;
    this.dodaj=1;
  }


  posaljiNarudzbinu(){
    if(this.narSadnice.length==0 && this.narPreparati.length==0){
      this.responseMessage="Morate da dodate proizvode da biste poslali narudzbinu.";
      return;
    }
    else{
      var pred:string;
      if(this.narSadnice.length!=0){pred=this.narSadnice[0].pred;}
      else{pred=this.narPreparati[0].pred;}
      this.api.dodajNarudzbinu(this.User,this.Pass,this.narRasadnik,pred).subscribe(data=>{
        if(data==-1){this.responseMessage="Dogodila se greska prilikom kreiranja narudzbine."; return;}
        else if(data==0){this.responseMessage="Dati rasadnik ne postoji!"; return;}
        else{
          this.narId=data;
          this.narPreparati.forEach((el) =>{
            this.api.dodajNarPreparat(this.User,this.Pass,this.narId,el).subscribe(data=>{/*alert(el.naziv + ": " +data);*/});
          });
          this.narSadnice.forEach((el) =>{
            this.api.dodajNarSadnicu(this.User,this.Pass,this.narId,el).subscribe(data=>{/*alert(el.naziv + ": " +data);*/});
          });
          this.responseMessage="Uspesno poslata narudzbina sa id-jem: " + this.narId;
          this.addMessage="";
          this.tempPreparat=new Preparat;
          this.tempSadnica=new Sadnica;
          return;
        }
      });
    }
  }


  ukloniNarSadnicu(s:Sadnica){
    var index = this.narSadnice.indexOf(s);
    this.narSadnice.splice(index,1);
  }

  ukloniNarPreparat(p:Preparat){
    var index=this.narPreparati.indexOf(p);
    this.narPreparati.splice(index,1);
  }

  otvoriSadnicu(sad:Sadnica){
    localStorage.setItem("SadnicaPP",JSON.stringify(sad));
    localStorage.setItem("SadnicaP",null);
    localStorage.setItem("PreparatP",null);
    localStorage.setItem("PreparatPP",null);
    localStorage.setItem("ret","/prodavnica");
    this.router.navigate(["/proizvod"]);
  }

  otvoriPreparat(prep:Preparat){
    localStorage.setItem("PreparatPP",JSON.stringify(prep));
    localStorage.setItem("SadnicaPP",null);
    localStorage.setItem("SadnicaP",null);
    localStorage.setItem("PreparatP",null);
    localStorage.setItem("ret","/prodavnica");
    this.router.navigate(["/proizvod"]);
  }

}
